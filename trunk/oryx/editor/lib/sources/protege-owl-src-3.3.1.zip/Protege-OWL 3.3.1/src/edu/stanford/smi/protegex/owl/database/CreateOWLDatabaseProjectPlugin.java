/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.database;

import edu.stanford.smi.protege.model.KnowledgeBaseFactory;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.plugin.AbstractCreateProjectPlugin;
import edu.stanford.smi.protege.plugin.CreateProjectWizard;
import edu.stanford.smi.protege.storage.database.DatabaseKnowledgeBaseFactory;
import edu.stanford.smi.protege.util.Log;
import edu.stanford.smi.protege.util.PropertyList;
import edu.stanford.smi.protege.util.WizardPage;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author Ray Fergerson  <fergerson@smi.stanford.edu>
 * @author Holger Knublauch  <holger@knublauch.com>
 */
public class CreateOWLDatabaseProjectPlugin extends
        AbstractCreateProjectPlugin implements OWLDatabasePlugin {

    private String driver;

    private String table;

    private String username;

    private String password;

    protected URI ontologyFileURI;

    private String url;


    public CreateOWLDatabaseProjectPlugin() {
        this("OWL Database");
    }


    public CreateOWLDatabaseProjectPlugin(String name) {
        super(name);
    }


    public boolean canCreateProject(KnowledgeBaseFactory factory, boolean useExistingSources) {
        return factory.getClass() == OWLDatabaseKnowledgeBaseFactory.class;
    }


    public Project createNewProject(KnowledgeBaseFactory factory) {
        Collection errors = new ArrayList();
        Project project = super.createNewProject(factory);
        initializeSources(project.getSources());
        try {
            File tempProjectFile = File.createTempFile("protege", "temp");
            project.setProjectFilePath(tempProjectFile.getPath());
            project.save(errors);
            if(errors.isEmpty()) {
                project = Project.loadProjectFromFile(tempProjectFile.getPath(), errors);
            }
            handleErrors(errors);
            project.setProjectFilePath(null);
            tempProjectFile.delete();
        }
        catch (IOException e) {
            Log.getLogger().severe(Log.toString(e));
        }
        return project;
    }


    public WizardPage createCreateProjectWizardPage(CreateProjectWizard wizard,
                                                    boolean useExistingSources) {
        return new OWLDatabaseWizardPage(wizard, this, useExistingSources);
    }


    protected void initializeSources(PropertyList sources) {
        DatabaseKnowledgeBaseFactory.setSources(sources, driver, url, table, username, password);
    }


    public void setDriver(String driver) {
        this.driver = driver;
    }


    public void setOntologyFileURI(URI uri) {
        this.ontologyFileURI = uri;
    }


    public void setTable(String table) {
        this.table = table;
    }


    public void setURL(String url) {
        this.url = url;
    }


    public void setUsername(String username) {
        this.username = username;
    }


    public void setPassword(String password) {
        this.password = password;
    }
}