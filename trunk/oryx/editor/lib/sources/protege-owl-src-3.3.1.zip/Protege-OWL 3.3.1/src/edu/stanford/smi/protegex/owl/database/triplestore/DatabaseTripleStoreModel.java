/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.database.triplestore;

import edu.stanford.smi.protege.model.framestore.NarrowFrameStore;
import edu.stanford.smi.protegex.owl.database.OWLDatabaseModel;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;
import edu.stanford.smi.protegex.owl.model.triplestore.impl.AbstractTripleStoreModel;
import edu.stanford.smi.protegex.owl.model.triplestore.impl.TripleChangePostProcessor;

/**
 * @author Holger Knublauch  <holger@knublauch.com>
 */
public class DatabaseTripleStoreModel extends AbstractTripleStoreModel {

    private TripleStore systemTripleStore;

    private DatabaseTripleStore userTripleStore;


    public DatabaseTripleStoreModel(OWLDatabaseModel owlModel) {
        super(owlModel);
       
        NarrowFrameStore frameStore = mnfs.getActiveFrameStore();
        userTripleStore = new DatabaseTripleStore(owlModel, this, frameStore);
        NarrowFrameStore systemFrameStore = mnfs.getSystemFrameStore();
        this.systemTripleStore = new DatabaseTripleStore(owlModel, this, systemFrameStore);
        ts.add(systemTripleStore);
        ts.add(userTripleStore);
        if (userTripleStore.getName() == null) {
            userTripleStore.setName("top");
        }
    }

    /**
     * This is a constructor for the case when the model does not have a narrow frame store.
     * <p/>
     * For example, server side OWL models do not have narrow frame stores.
     *
     * @param owlModel
     * @param systemNfs a substitute system narrow frame store
     * @param userNfs a substitute  user narrow frame store.
     */
    public DatabaseTripleStoreModel(OWLDatabaseModel owlModel, 
                                    NarrowFrameStore systemNfs, 
                                    NarrowFrameStore userNfs) {
        super(owlModel);
       
        userTripleStore = new DatabaseTripleStore(owlModel, this, userNfs);
        systemTripleStore = new DatabaseTripleStore(owlModel, this, systemNfs);
        ts.add(systemTripleStore);
        ts.add(userTripleStore);
        if (userTripleStore.getName() == null) {
            userTripleStore.setName("top");
        }
    }


    public TripleStore createTripleStore(String name) {
        return userTripleStore;
    }


    public void deleteTripleStore(TripleStore tripleStore) {
    }

    public TripleStore getTripleStoreByDefaultNamespace(String namespace) {
        return userTripleStore;
    }
}
