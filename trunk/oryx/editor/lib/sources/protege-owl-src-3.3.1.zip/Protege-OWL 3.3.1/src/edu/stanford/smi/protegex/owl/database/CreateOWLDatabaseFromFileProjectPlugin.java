/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.database;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;

import edu.stanford.smi.protege.model.KnowledgeBaseFactory;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.model.framestore.MergingNarrowFrameStore;
import edu.stanford.smi.protege.plugin.CreateProjectWizard;
import edu.stanford.smi.protege.util.Log;
import edu.stanford.smi.protege.util.MessageError;
import edu.stanford.smi.protege.util.WizardPage;
import edu.stanford.smi.protegex.owl.jena.JenaKnowledgeBaseFactory;
import edu.stanford.smi.protegex.owl.jena.parser.ProtegeOWLParser;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;

/**
 * @author Holger Knublauch  <holger@knublauch.com>
 */
public class CreateOWLDatabaseFromFileProjectPlugin extends CreateOWLDatabaseProjectPlugin {

    public CreateOWLDatabaseFromFileProjectPlugin() {
        super("OWL File (.owl or .rdf)");
    }


    protected Project buildNewProject(KnowledgeBaseFactory factory) {
        JenaKnowledgeBaseFactory.useStandalone = false;
        Collection errors = new ArrayList();
        Project project = super.createNewProject(factory);
        initializeSources(project.getSources());
        try {
            File tempProjectFile = File.createTempFile("protege", "temp");
            project.setProjectFilePath(tempProjectFile.getPath());
            project.save(errors);
            project = Project.loadProjectFromFile(tempProjectFile.getPath(), errors);

            OWLDatabaseModel owlModel = (OWLDatabaseModel) project.getKnowledgeBase();
            updateTripleStores(owlModel);
            ProtegeOWLParser parser = new ProtegeOWLParser(owlModel, false);
            try {
                parser.run(ontologyFileURI);
            }
            catch (Exception ex) {
            	String message = "Could not load OWL file into database";
                Log.getLogger().severe(message);
                Log.getLogger().log(Level.SEVERE, "Exception caught", ex);
                errors.add(new MessageError(ex, message));
            }
            owlModel.resetTripleStoreModel();
            handleErrors(errors);
            project.setProjectFilePath(null);
            tempProjectFile.delete();
            updateTripleStores(owlModel);

            // Sorting doesn't seem to work yet
            //System.out.println("Sorting subclasses...");
            //OWLUtil.sortSubclasses(owlModel);
            //System.out.println("... done");
        }
        catch (IOException e) {
            Log.getLogger().severe(Log.toString(e));
        }
        return project;
    }


    private void updateTripleStores(OWLDatabaseModel owlModel) {
        owlModel.resetTripleStoreModel();
        TripleStore topTripleStore = owlModel.getTripleStoreModel().getTopTripleStore();
        owlModel.getTripleStoreModel().setActiveTripleStore(topTripleStore);
        MergingNarrowFrameStore mnfs = MergingNarrowFrameStore.get(owlModel);
        mnfs.setTopFrameStore(mnfs.getActiveFrameStore().getName());
    }


    public boolean canCreateProject(KnowledgeBaseFactory factory, boolean useExistingSources) {
        return super.canCreateProject(factory, useExistingSources) && useExistingSources;
    }


    public WizardPage createCreateProjectWizardPage(CreateProjectWizard wizard, boolean useExistingSources) {
        return new InitOWLDatabaseFromFileWizardPage(wizard, this);
    }
}
