/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.model.impl;

import edu.stanford.smi.protege.model.FrameID;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protegex.owl.model.OWLNames;
import edu.stanford.smi.protegex.owl.model.OWLObjectProperty;
import edu.stanford.smi.protegex.owl.model.RDFSClass;
import edu.stanford.smi.protegex.owl.model.RDFSNamedClass;
import edu.stanford.smi.protegex.owl.model.visitor.OWLModelVisitor;
import edu.stanford.smi.protegex.owl.ui.icons.OWLIcons;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Collection;

/**
 * The default implementation of the OWLObjectProperty interface.
 *
 * @author Holger Knublauch  <holger@knublauch.com>
 */
public class DefaultOWLObjectProperty extends AbstractOWLProperty implements OWLObjectProperty {

    public DefaultOWLObjectProperty(KnowledgeBase kb, FrameID id) {
        super(kb, id);
    }


    public DefaultOWLObjectProperty() {
    }


    public void addUnionRangeClass(RDFSClass rangeClass) {
        Collection unionRange = new ArrayList(getUnionRangeClasses());
        if (!unionRange.contains(rangeClass)) {
            unionRange.add(rangeClass);
            setUnionRangeClasses(unionRange);
        }
    }


    public String getIconName() {
        if(isAnnotationProperty()) {
            return OWLIcons.OWL_OBJECT_ANNOTATION_PROPERTY;
        }
        else {
            return OWLIcons.OWL_OBJECT_PROPERTY;
        }
    }


    public Icon getInheritedIcon() {
        return OWLIcons.getImageIcon(OWLIcons.OWL_OBJECT_PROPERTY_INHERITED);
    }


    public Collection getUnionRange() {
        return getAllowedClses();
    }


    public boolean hasObjectRange() {
        return true;
    }


    public boolean isSymmetric() {
        RDFSNamedClass metaclass = getOWLModel().getRDFSNamedClass(OWLNames.Cls.SYMMETRIC_PROPERTY);
        return hasProtegeType(metaclass);
    }


    public boolean isTransitive() {
        RDFSNamedClass metaclass = getOWLModel().getRDFSNamedClass(OWLNames.Cls.TRANSITIVE_PROPERTY);
        return hasProtegeType(metaclass);
    }


    public void removeUnionRangeClass(RDFSClass rangeClass) {
        Collection unionRange = new ArrayList(getUnionRange());
        if (unionRange.contains(rangeClass)) {
            unionRange.remove(rangeClass);
            setUnionRangeClasses(unionRange);
        }
    }


    public void setSymmetric(boolean value) {
        RDFSNamedClass metaclass = getOWLModel().getRDFSNamedClass(OWLNames.Cls.SYMMETRIC_PROPERTY);
        updateRDFType(value, metaclass);
    }


    public void setTransitive(boolean value) {
        RDFSNamedClass metaclass = getOWLModel().getRDFSNamedClass(OWLNames.Cls.TRANSITIVE_PROPERTY);
        updateRDFType(value, metaclass);
    }


    public void accept(OWLModelVisitor visitor) {
        visitor.visitOWLObjectProperty(this);
    }

}
