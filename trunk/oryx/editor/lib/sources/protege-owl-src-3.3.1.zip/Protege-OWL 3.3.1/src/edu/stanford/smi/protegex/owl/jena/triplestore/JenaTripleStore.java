/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.jena.triplestore;

import edu.stanford.smi.protege.model.Frame;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Model;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protege.model.framestore.InMemoryFrameDb;
import edu.stanford.smi.protege.model.framestore.NarrowFrameStore;
import edu.stanford.smi.protege.model.framestore.Record;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.model.impl.DefaultRDFSLiteral;
import edu.stanford.smi.protegex.owl.model.triplestore.Triple;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreModel;
import edu.stanford.smi.protegex.owl.model.triplestore.impl.AbstractTripleStore;
import edu.stanford.smi.protegex.owl.model.triplestore.impl.DefaultTriple;

import java.util.*;

/**
 * A TripleStore that acts as a view on an existing NarrowFrameStore.
 *
 * @author Holger Knublauch  <holger@knublauch.com>
 */
public class JenaTripleStore extends AbstractTripleStore {


    public JenaTripleStore(OWLModel owlModel, NarrowFrameStore frameStore, TripleStoreModel tripleStoreModel) {
        super(owlModel, tripleStoreModel, frameStore);
    }


    public boolean equals(Object obj) {
        if (obj instanceof JenaTripleStore) {
            return frameStore.getName().equals(((JenaTripleStore) obj).frameStore.getName());
        }
        else {
            return false;
        }
    }


    public Iterator listTriples() {
	    // TODO: This could be optimised so that a custom Iterator is used.
        KnowledgeBase kb = owlModel;
        Collection<Slot> ignoreProperties = new HashSet<Slot>();
        ignoreProperties.add(owlModel.getRDFProperty(OWLNames.Slot.ONTOLOGY_PREFIXES));
        ignoreProperties.add(kb.getSlot(Model.Slot.DIRECT_INSTANCES));
        ignoreProperties.add(kb.getSlot(Model.Slot.DIRECT_TYPES));
        ignoreProperties.add(kb.getSlot(ProtegeNames.Slot.CLASSIFICATION_STATUS));
        ignoreProperties.add(kb.getSlot(ProtegeNames.Slot.INFERRED_SUBCLASSES));
        ignoreProperties.add(kb.getSlot(ProtegeNames.Slot.INFERRED_SUPERCLASSES));
        ignoreProperties.add(kb.getSlot(ProtegeNames.Slot.INFERRED_TYPE));
        List triples = new ArrayList();
        Collection records = ((InMemoryFrameDb) frameStore).getRecords();
        for (Iterator it = records.iterator(); it.hasNext();) {
            Record record = (Record) it.next();
            Frame subject = record.getFrame();
            if (subject instanceof RDFResource) {
                Slot predicate = record.getSlot();
                // System.out.println("-- " + subject.getName() + " . " + predicate.getName());
                if (predicate instanceof RDFProperty) {
                    if (record.getFacet() == null && !record.isTemplate() && !ignoreProperties.contains(predicate)) {
                        List values = record.getValues();
                        for (Iterator vit = values.iterator(); vit.hasNext();) {
                            Object object = vit.next();
                            if (object instanceof String && DefaultRDFSLiteral.isRawValue((String) object)) {
                                object = new DefaultRDFSLiteral(owlModel, (String) object);
                            }
                            Triple triple = new DefaultTriple((RDFResource) subject, (RDFProperty) predicate, object);
                            triples.add(triple);
                        }
                    }
                }
            }
        }
        return triples.iterator();
    }
    
    @Override
    public int hashCode() {
    	return 0;    	
    }
    
}
