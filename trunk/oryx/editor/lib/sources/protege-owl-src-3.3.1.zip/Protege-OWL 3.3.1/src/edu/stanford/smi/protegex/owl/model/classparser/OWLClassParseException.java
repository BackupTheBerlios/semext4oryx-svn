/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.model.classparser;

import edu.stanford.smi.protegex.owl.model.RDFProperty;

/**
 * An Exception thrown by an OWLClassParser, providing additional information that can be
 * used to guide user input.
 *
 * @author Holger Knublauch  <holger@knublauch.com>
 */
public class OWLClassParseException extends Exception {

    public String currentToken;

    public boolean nextCouldBeClass;

    public boolean nextCouldBeIndividual;

    public boolean nextCouldBeProperty;

	public boolean nextCouldBeDatatypeName;

    public RDFProperty recentHasValueProperty;

    private static OWLClassParseException recentInstance = new OWLClassParseException("");


    public OWLClassParseException(String message) {
        super(message);
        recentInstance = this;
    }


    /**
     * Gets the most recently created exception of this type.
     * This can be used to guide input in text fields etc.
     *
     * @return the most recently created exception
     */
    public static OWLClassParseException getRecentInstance() {
        return recentInstance;
    }
}
