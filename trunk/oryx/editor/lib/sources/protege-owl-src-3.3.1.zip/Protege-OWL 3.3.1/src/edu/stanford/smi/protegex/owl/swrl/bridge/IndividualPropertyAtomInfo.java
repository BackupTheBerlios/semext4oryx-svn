/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */


// Info object representing a SWRL individual property atom. 

package edu.stanford.smi.protegex.owl.swrl.bridge;

import edu.stanford.smi.protegex.owl.swrl.model.SWRLIndividualPropertyAtom;
import edu.stanford.smi.protegex.owl.swrl.bridge.exceptions.SWRLRuleEngineBridgeException;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLVariable;
import edu.stanford.smi.protegex.owl.model.OWLIndividual;

public class IndividualPropertyAtomInfo extends AtomInfo
{
    private String propertyName;
    private Argument argument1, argument2;

  public IndividualPropertyAtomInfo(SWRLIndividualPropertyAtom atom) throws SWRLRuleEngineBridgeException
  {
    propertyName = (atom.getPropertyPredicate() != null) ? atom.getPropertyPredicate().getName() : null;

    if (propertyName == null) throw new SWRLRuleEngineBridgeException("Empty property name in SWRLIndividualPropertyAtom: " + atom);
    
    if (atom.getArgument1() instanceof SWRLVariable) {
      SWRLVariable variable = (SWRLVariable)atom.getArgument1();
      ObjectVariableInfo argument = new ObjectVariableInfo(variable);
      addReferencedVariable(variable.getName(), argument);
      argument1 = argument;
    } else if (atom.getArgument1() instanceof OWLIndividual) argument1 = new IndividualInfo((OWLIndividual)atom.getArgument1());
    else throw new SWRLRuleEngineBridgeException("Unexpected argument #1 to individual property atom '" + atom.getBrowserText() + "'. Expecting variable or individual, got instance of " + atom.getArgument1().getClass() + ".");

    if (atom.getArgument2() instanceof SWRLVariable) {
      SWRLVariable variable = (SWRLVariable)atom.getArgument2();
      ObjectVariableInfo argument = new ObjectVariableInfo(variable);
      addReferencedVariable(variable.getName(), argument);
      argument2 = argument;
    } else if (atom.getArgument2() instanceof OWLIndividual) argument2 = new IndividualInfo((OWLIndividual)atom.getArgument2());
    else throw new SWRLRuleEngineBridgeException("Unexpected argument #2 to individual property atom '" + atom.getBrowserText() + "'. Expecting variable or individual, got instance of " + atom.getArgument2().getClass() + ".");

    // If argument1 or 2 is an individual, add its name to the referenced individuals list for this atom.

    if (argument1 instanceof IndividualInfo) {
	IndividualInfo individualInfo = (IndividualInfo)argument1;
	addReferencedIndividualName(individualInfo.getIndividualName());
    } // if

    if (argument2 instanceof IndividualInfo) {
	IndividualInfo individualInfo = (IndividualInfo)argument2;
	addReferencedIndividualName(individualInfo.getIndividualName());
    } // if
  } // IndividualPropertyAtomInfo

  public String getPropertyName() { return propertyName; }  
  public Argument getArgument1() { return argument1; }
  public Argument getArgument2() { return argument2; }  
} // IndividualPropertyAtomInfo
