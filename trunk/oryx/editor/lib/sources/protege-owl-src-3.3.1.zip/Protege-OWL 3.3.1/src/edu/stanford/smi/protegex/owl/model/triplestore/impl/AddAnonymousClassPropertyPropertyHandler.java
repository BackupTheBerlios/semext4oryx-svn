/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.model.triplestore.impl;

import java.util.Iterator;
import java.util.logging.Level;

import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.model.Frame;
import edu.stanford.smi.protege.model.FrameID;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Model;
import edu.stanford.smi.protege.util.Log;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.owl.model.impl.DefaultRDFProperty;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreModel;

/**
 * @author Holger Knublauch  <holger@knublauch.com>
 */
class AddAnonymousClassPropertyPropertyHandler extends AbstractAddPropertyValueHandler {

    private RDFProperty directInstancesSlot;

    private RDFProperty directTypesSlot;

    private Class javaType;

    private KnowledgeBase kb;

    private Cls newType;

    private TripleStoreModel tripleStoreModel;


    AddAnonymousClassPropertyPropertyHandler(ProtegeTripleAdder adder,
                                             Cls newType,
                                             Class javaType,
                                             TripleStoreModel tripleStoreModel) {
        super(adder);
        this.javaType = javaType;
        this.kb = newType.getKnowledgeBase();
        this.newType = newType;
        this.tripleStoreModel = tripleStoreModel;
        KnowledgeBase kb = newType.getKnowledgeBase();
        directInstancesSlot = new DefaultRDFProperty(kb, Model.SlotID.DIRECT_INSTANCES);
        directTypesSlot = new DefaultRDFProperty(kb, Model.SlotID.DIRECT_TYPES);
    }


    public void handleAdd(RDFResource subject, Object object) {
        removeDirectTypes(subject);
        if (subject.getClass() != javaType) {
            try {
                subject = (RDFResource) javaType.getConstructor(new Class[]{
                        KnowledgeBase.class,
                        FrameID.class
                }).newInstance(new Object[]{
                        kb,
                        ((Frame) subject).getFrameID()
                });
            }
            catch (Exception ex) {
              Log.getLogger().log(Level.SEVERE, "Exception caught", ex);
            }
            tripleStoreModel.replaceJavaObject(subject);
            // ProtegeOWLParser.resourceName2Frame.put(ProtegeOWLParser.currentNode, subject);
        }
        if (adder.addValue(subject, directTypesSlot, newType)) {
            adder.addValueFast(newType, directInstancesSlot, subject);
        }
    }


    private void removeDirectTypes(RDFResource subject) {
        for (Iterator it = tripleStoreModel.getTripleStores().iterator(); it.hasNext();) {
            TripleStore tripleStore = (TripleStore) it.next();
            for (Iterator vit = tripleStore.listObjects(subject, directTypesSlot); vit.hasNext();) {
                RDFResource type = (RDFResource) vit.next();
                vit.remove();
                tripleStore.remove(subject, directTypesSlot, type);
                tripleStore.remove(type, directInstancesSlot, subject);
            }
        }
    }
}
