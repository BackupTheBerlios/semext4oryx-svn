/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */


package edu.stanford.smi.protegex.owl.swrl;

import edu.stanford.smi.protegex.owl.swrl.exceptions.*;
import edu.stanford.smi.protegex.owl.swrl.bridge.query.Result;
import edu.stanford.smi.protegex.owl.swrl.bridge.query.exceptions.ResultException;

import java.util.*;


/**
 ** This inferface defines the methods that must be provided by a SWRL rule engine.
 **
 */
public interface SWRLRuleEngine
{
  /**
   ** Load rules and knowledge from OWL into bridge, send them to a rule engine, run the rule engine, and write any inferred knowledge back
   ** to OWL.
   */
  void infer() throws SWRLRuleEngineException;

  /**
   ** Load rules and knowledge from OWL into bridge. All existing bridge rules and knowledge will first be cleared and the associated rule
   ** engine will be reset.
   */
  void importSWRLRulesAndOWLKnowledge() throws SWRLRuleEngineException;

  /**
   ** Load rules from a particular rule group and associated knowledge from OWL into bridge. All existing bridge rules and knowledge will
   ** first be cleared and the associated rule engine will be reset.
   */
  void importSWRLRulesAndOWLKnowledge(String ruleGroupName) throws SWRLRuleEngineException;

  /**
   ** Load rules from all the named rule groups and associated knowledge from OWL into bridge. All existing bridge rules and knowledge will
   ** first be cleared and the associated rule engine will be reset.
   */
  void importSWRLRulesAndOWLKnowledge(Set<String> ruleGroupNames) throws SWRLRuleEngineException;

  /**
   ** Run the rule engine.
   */
  void run() throws SWRLRuleEngineException;

  /**
   ** Send rules and knowledge stored in bridge to a rule engine.
   */
  void exportSWRLRulesAndOWLKnowledge() throws SWRLRuleEngineException;

  /**
   ** Send knowledge (excluding SWRL rules) stored in bridge to a rule engine.
   */
  void exportOWLKnowledge() throws SWRLRuleEngineException;

  /**
   ** Write knowledge inferred by rule engine back to OWL.
   */
  void writeAssertedIndividualsAndProperties2OWL() throws SWRLRuleEngineException;

  /**
   **  Clear all knowledge from rule engine, deleted asserted knowledge from the bridge, and leave imported bridge knowledge intact.
   */
  void resetRuleEngine() throws SWRLRuleEngineException;

  /**
   **  Get the results from a rule containing query built-ins. Null is retured if there are no results or if the query subsystem is not
   **  activated.
   */
  Result getQueryResult(String ruleName) throws ResultException;

} // SWRLRuleEngine
