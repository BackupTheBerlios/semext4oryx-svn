/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */


// Base class representing information about atoms in a SWRL rule.

package edu.stanford.smi.protegex.owl.swrl.bridge;

import java.util.*;

public class AtomInfo extends Info 
{
  private Set<String> referencedIndividualNames;
  private HashMap<String, VariableInfo> referencedVariables;

  public AtomInfo() 
  { 
    referencedIndividualNames = new HashSet<String>();
    referencedVariables = new HashMap<String, VariableInfo>();
  } // ArrayList

  public boolean hasReferencedIndividuals() { return referencedIndividualNames.size() != 0; }
  public Set<String> getReferencedIndividualNames() { return referencedIndividualNames; }
  public boolean hasReferencedVariables() { return referencedVariables.size() != 0; }
  public Set<String> getReferencedVariableNames() { return referencedVariables.keySet(); }

  public Set<String> getReferencedObjectVariableNames() 
  {
    Set<String> result = new HashSet<String>();
    
    for (String variableName: getReferencedVariableNames()) {
      if (isReferencedObjectVariable(variableName)) result.add(variableName);
    } // for
    return result;
  } // getReferencedObjectVariableNames
  
  public Set<String> getReferencedDatatypeVariableNames() 
  {
    Set<String> result = new HashSet<String>();
    
    for (String variableName: getReferencedVariableNames()) {
      if (isReferencedDatatypeVariable(variableName)) result.add(variableName);
    } // while
    return result;
  } // getReferencedDatatypeVariableNames
  
  public boolean isReferencedObjectVariable(String variableName) 
  { 
    return referencedVariables.containsKey(variableName) && referencedVariables.get(variableName) instanceof ObjectVariableInfo; 
  } // isReferencedObjectVariable
  
  public boolean isReferencedDatatypeVariable(String variableName) 
  { 
    return referencedVariables.containsKey(variableName) && referencedVariables.get(variableName) instanceof DatatypeVariableInfo; 
  }
  
  protected void addReferencedIndividualName(String individualName) 
  { 
    if (!referencedIndividualNames.contains(individualName)) referencedIndividualNames.add(individualName); 
  } // addReferencedIndividualName
  
  protected void addReferencedVariable(String variableName, VariableInfo variableInfo) 
  { 
    if (!referencedVariables.containsKey(variableName)) referencedVariables.put(variableName, variableInfo); 
  } // addReferencedVariable
} // AtomInfo
