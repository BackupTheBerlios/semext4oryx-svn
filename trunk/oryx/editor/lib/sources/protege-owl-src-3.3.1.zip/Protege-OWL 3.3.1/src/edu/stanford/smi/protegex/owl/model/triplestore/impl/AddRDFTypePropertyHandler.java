/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.model.triplestore.impl;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.owl.model.OWLNames;
import edu.stanford.smi.protegex.owl.model.RDFNames;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreModel;

import java.util.Collection;

/**
 * @author Holger Knublauch  <holger@knublauch.com>
 */
class AddRDFTypePropertyHandler extends AbstractAddPropertyValueHandler {

    private Slot directInstancesSlot;

    private Slot directTypesSlot;

    private Cls owlClassClass;

    private TripleStore tripleStore;

    private TripleStoreModel tripleStoreModel;

    private Cls untypedResourceClass;


    AddRDFTypePropertyHandler(ProtegeTripleAdder adder, KnowledgeBase kb, TripleStoreModel tripleStoreModel, TripleStore tripleStore) {
        super(adder);
        directInstancesSlot = kb.getSlot(Model.Slot.DIRECT_INSTANCES);
        directTypesSlot = kb.getSlot(Model.Slot.DIRECT_TYPES);
        owlClassClass = kb.getCls(OWLNames.Cls.NAMED_CLASS);
        untypedResourceClass = kb.getCls(RDFNames.Cls.EXTERNAL_RESOURCE);
        this.tripleStoreModel = tripleStoreModel;
        this.tripleStore = tripleStore;
    }



    public void handleAdd(RDFResource subject, Object object) {
        // Don't add owl:Class if this already has a type (e.g., :OWL-COMPLEMENT-CLASS)
        
        Collection oldValues = adder.getSlotValues(subject, directTypesSlot);

        if (oldValues.isEmpty()) {
            tripleStoreModel.setHomeTripleStore(subject, tripleStore);
        }
        
        if (!object.equals(owlClassClass)) {
            if (adder.addValue(subject, directTypesSlot, object)) {
                adder.addValueFast((Instance) object, directInstancesSlot, subject);
            }
        } else if (oldValues.isEmpty()) {
            if (adder.addValue(subject, directTypesSlot, object)) {
                adder.addValueFast((Instance) object, directInstancesSlot, subject);
            }
        }     
        
        if (oldValues.size() == 1 && oldValues.contains(untypedResourceClass)) {
            ((Instance) subject).removeDirectType(untypedResourceClass);
            tripleStoreModel.setHomeTripleStore(subject, tripleStore);
        } 
    }
}
