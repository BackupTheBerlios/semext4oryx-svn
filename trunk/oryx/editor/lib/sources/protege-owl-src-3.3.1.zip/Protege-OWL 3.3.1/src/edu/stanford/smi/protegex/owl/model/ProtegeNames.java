/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.model;

import com.hp.hpl.jena.ontology.AnnotationProperty;
import com.hp.hpl.jena.ontology.OntModel;

/**
 * The namespaces and names from the Protege meta ontology.
 * This ontology is used to represent Protege-specific metadata such as
 * whether a class is abstract or not.
 *
 * @author Holger Knublauch  <holger@knublauch.com>
 */
public class ProtegeNames {

	public final static String PREFIX_LOCALNAME_SEPARATOR = ":";

	public final static String DEFAULT_ONTOLOGY = ":";

    public static String PROTEGE_PREFIX = "protege";

    public final static String PREFIX = PROTEGE_PREFIX + ":";


    public static interface Slot {

        final static String ABSTRACT = PREFIX + "abstract";

        final static String CLASSIFICATION_STATUS = PREFIX + "classificationStatus";

        final static String INFERRED_TYPE = PREFIX + "inferredType";

        final static String INFERRED_SUBCLASSES = PREFIX + "inferredSuperclassOf";

        final static String INFERRED_SUPERCLASSES = PREFIX + "inferredSubclassOf";

	    final static String IS_COMMENTED_OUT = PREFIX + "isCommentedOut";
    }

    public static String FILE = "http://protege.stanford.edu/plugins/owl/protege";

    public final static String NS = FILE + "#";

    public final static String ABSTRACT = "abstract";

    public final static String ALLOWED_PARENT = "allowedParent";

    public final static String DEFAULT_LANGUAGE = "defaultLanguage";

    public final static String EXCLUDED_TEST = "excludedTest";

    public final static String PROBE_CLASS = "probeClass";

    public static final String READ_ONLY = "readOnly";

    public final static String SUBCLASSES_DISJOINT = "subclassesDisjoint";

    public final static String TODO_PREFIX = "todoPrefix";

    public final static String TODO_PROPERTY = "todoProperty";

    public final static String RDFS_SUB_CLASS_OF_INVERSE = "superClassOf";

    public final static String RDFS_SUB_CLASS_OF_INVERSE_PREFIXED = PREFIX + RDFS_SUB_CLASS_OF_INVERSE;

    /**
     * Not represented as a property yet, but in the future the
     * :DIRECT-INSTANCES system slot could be mapped into this,
     * to access the inverses of rdf:type
     */
    public final static String RDF_TYPE_INVERSE = "typeOf";

    public final static String RDF_TYPE_INVERSE_PREFIXED = PREFIX + RDF_TYPE_INVERSE;

    public final static String USED_LANGUAGE = "usedLanguage";


    public static AnnotationProperty getAbstractProperty(OntModel ontModel) {
        return ontModel.getAnnotationProperty(NS + ABSTRACT);
    }


    public static AnnotationProperty getAllowedParentProperty(OntModel ontModel) {
        return ontModel.getAnnotationProperty(NS + ALLOWED_PARENT);
    }


    public static String getProbeClassSlotName() {
        return PREFIX + PROBE_CLASS;
    }


    public static String getReadOnlySlotName() {
        return PREFIX + READ_ONLY;
    }


    public static String getSubclassesDisjointSlotName() {
        return PREFIX + SUBCLASSES_DISJOINT;
    }


    public static String getTodoPrefixSlotName() {
        return PREFIX + TODO_PREFIX;
    }


    public static String getTodoPropertySlotName() {
        return PREFIX + TODO_PROPERTY;
    }


    public static String getDefaultLanguageSlotName() {
        return PREFIX + DEFAULT_LANGUAGE;
    }


    public static String getUsedLanguagesSlotName() {
        return PREFIX + USED_LANGUAGE;
    }


}
