/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.model.framestore;

import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.model.Facet;
import edu.stanford.smi.protege.model.Model;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.model.impl.AbstractOWLModel;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

class HasValueRestrictionUpdater extends AbstractRestrictionUpdater {

    private Facet valuesFacet;


    HasValueRestrictionUpdater(AbstractOWLModel owlModel) {
        super(owlModel);
        valuesFacet = owlModel.getFacet(Model.Facet.VALUES);
    }


    // Implements RestrictionUpdater
    public void copyFacetValuesIntoNamedClass(RDFSNamedClass cls, OWLRestriction restriction) {
        Slot slot = restriction.getOnProperty();
        if (slot != null) {
            updateValuesFacet(cls, slot);
        }
    }


    // Implements RestrictionUpdater
    public void updateRestrictions(OWLNamedClass cls, RDFProperty property, Facet facet) {
        removeRestrictions(cls, property, owlModel.getCls(OWLNames.Cls.HAS_VALUE_RESTRICTION));
        if (((Cls) cls).hasDirectlyOverriddenTemplateFacet(property, valuesFacet)) {
            Collection values = ((Cls) cls).getTemplateSlotValues(property);
            for (Iterator it = values.iterator(); it.hasNext();) {
                Object value = it.next();
                OWLHasValue restriction = owlModel.createOWLHasValue(property, value);
                cls.addSuperclass(restriction);
                log("+ OWLHasValue " + restriction.getBrowserText() + " to " + cls.getName() + "." + property.getName());
            }
        }
    }


    void updateValuesFacet(RDFSNamedClass cls, Slot slot) {
        ((Cls) cls).setTemplateFacetValues(slot, valuesFacet, Collections.EMPTY_LIST); // was: null
        log("- :VALUES override from " + cls.getName() + "." + slot.getName());
        for (Iterator it = getDirectRestrictions(cls, slot, OWLHasValue.class).iterator(); it.hasNext();) {
            OWLHasValue r = (OWLHasValue) it.next();
            if (r != null) {
                Object value = r.getHasValue();
                if (value != null) {
                    if (value instanceof RDFSLiteral) {
                        value = value.toString();
                    }
                    ((Cls) cls).addTemplateFacetValue(slot, valuesFacet, value);
                }
            }
        }
    }
}
