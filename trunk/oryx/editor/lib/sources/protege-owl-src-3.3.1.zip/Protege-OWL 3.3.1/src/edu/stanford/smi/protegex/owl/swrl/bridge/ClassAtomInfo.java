/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */


// Info object representing a SWRL class atom.

package edu.stanford.smi.protegex.owl.swrl.bridge;

import edu.stanford.smi.protegex.owl.swrl.model.SWRLClassAtom;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLVariable;
import edu.stanford.smi.protegex.owl.swrl.bridge.exceptions.SWRLRuleEngineBridgeException;
import edu.stanford.smi.protegex.owl.swrl.bridge.exceptions.InvalidResourceNameException;
import edu.stanford.smi.protegex.owl.model.OWLIndividual;

public class ClassAtomInfo extends AtomInfo
{
  private Argument argument1;
  private String className;
  
  public ClassAtomInfo(SWRLClassAtom atom) throws SWRLRuleEngineBridgeException
  {
    className = (atom.getClassPredicate() != null) ? atom.getClassPredicate().getName() : null;

    if (className == null) throw new SWRLRuleEngineBridgeException("Empty class name in SWRLClassAtom: " + atom);
    
    if (atom.getArgument1() instanceof SWRLVariable) {
      SWRLVariable variable = (SWRLVariable)atom.getArgument1();
      ObjectVariableInfo argument = new ObjectVariableInfo(variable);
      addReferencedVariable(variable.getName(), argument);
      argument1 = argument;
    } else if (atom.getArgument1() instanceof OWLIndividual) {
      IndividualInfo argument = new IndividualInfo((OWLIndividual)atom.getArgument1());
      addReferencedIndividualName(argument.getIndividualName());
      argument1 = argument;
    } else throw new SWRLRuleEngineBridgeException("Unexpected argument to class atom '" + atom.getBrowserText() + "'. Expecting " +
                                                   "variable or individual, got instance of " + atom.getArgument1().getClass() + ".");
  } // ClassAtomInfo
  
  public String getClassName() { return className; }
  public Argument getArgument1() { return argument1; }
} // ClassAtomInfo

