/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.model;

import edu.stanford.smi.protege.model.FrameID;


/**
 * Defines the names of the RDFS related parts of the OWL system ontology.
 * This corresponds to the Model interface in general Protege.
 *
 * @author Holger Knublauch  <holger@knublauch.com>
 */
public interface RDFSNames {

    public static interface Cls {

        final static String CONTAINER = "rdfs:Container";

        final static String DATATYPE = "rdfs:Datatype";

        final static String LITERAL = "rdfs:Literal";

        final static String NAMED_CLASS = "rdfs:Class";
    }


    public interface ClsID {

        FrameID NAMED_CLASS = FrameID.createSystem(9003);
    }

    public static interface Slot {

        final static String COMMENT = "rdfs:comment";

        final static String DOMAIN = "rdfs:domain";

        final static String IS_DEFINED_BY = "rdfs:isDefinedBy";

        final static String LABEL = "rdfs:label";

        /**
         * @deprecated use LABEL
         */
        final static String LABELS = "rdfs:label";

        final static String MEMBER = "rdfs:member";

        final static String RANGE = "rdfs:range";

        final static String SEE_ALSO = "rdfs:seeAlso";

        final static String SUB_CLASS_OF = "rdfs:subClassOf";

        final static String SUB_PROPERTY_OF = "rdfs:subPropertyOf";
    }

    final static String RDFS_PREFIX = "rdfs";
}
