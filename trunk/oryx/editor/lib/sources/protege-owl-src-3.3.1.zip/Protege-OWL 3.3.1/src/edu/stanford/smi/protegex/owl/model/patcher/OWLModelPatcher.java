/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.model.patcher;

import java.util.Iterator;

/**
 * A utility class that can add "missing" rdf:type triples so that
 * untyped resources are resolved into their most likely intended type.
 * <p/>
 * For example, if an untyped resource as object in an rdfs:domain triple,
 * then we can infer that the resource is an rdfs:Class (or more).
 *
 * @author Holger Knublauch  <holger@knublauch.com>
 */
public interface OWLModelPatcher {

    /**
     * Adds "missing" triples for untyped resources.
     * This method shall create a new TripleStore for the given namespace
     * and then add rdf:type triples into it for all resources from a given Iterator.
     * Note that the Iterator may also contain resources from other namespaces, which
     * shall be ignored.
     *
     * @param resources an Iterator of untyped RDFResources
     * @param namespace the namespace to patch
     */
    void patch(Iterator resources, String namespace);
}
