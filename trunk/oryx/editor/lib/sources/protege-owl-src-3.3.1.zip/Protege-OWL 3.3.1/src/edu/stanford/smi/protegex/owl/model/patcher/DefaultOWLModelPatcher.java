/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protegex.owl.model.patcher;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Reference;
import edu.stanford.smi.protege.model.framestore.FrameStore;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.OWLNames;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.owl.model.RDFSClass;
import edu.stanford.smi.protegex.owl.model.RDFSNamedClass;
import edu.stanford.smi.protegex.owl.model.impl.DefaultRDFProperty;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;

/**
 * @author Holger Knublauch  <holger@knublauch.com>
 */
public class DefaultOWLModelPatcher implements OWLModelPatcher {

    private Map objectTypeMap = new HashMap();


    public DefaultOWLModelPatcher(OWLModel owlModel) {
        objectTypeMap.put(owlModel.getRDFSDomainProperty(), owlModel.getRDFSNamedClassClass());
        objectTypeMap.put(owlModel.getRDFSRangeProperty(), owlModel.getRDFSNamedClassClass());
        objectTypeMap.put(owlModel.getRDFSSubPropertyOfProperty(), owlModel.getRDFPropertyClass());
        objectTypeMap.put(owlModel.getRDFSSubClassOfProperty(), owlModel.getRDFSNamedClassClass());
        objectTypeMap.put(owlModel.getRDFTypeProperty(), owlModel.getRDFSNamedClassClass());
        objectTypeMap.put(owlModel.getRDFProperty(OWLNames.Slot.ON_PROPERTY), owlModel.getRDFPropertyClass());
    }


    private RDFSNamedClass getRDFType(RDFResource resource) {
        KnowledgeBase kb = resource.getOWLModel();
        Iterator refs = kb.getReferences(resource, 1000).iterator();
        while (refs.hasNext()) {
            Reference ref = (Reference) refs.next();
            RDFSNamedClass type = (RDFSNamedClass) objectTypeMap.get(ref.getSlot());
            if (type != null) {
                return type;
            }
        }
        RDFProperty dummy = new DefaultRDFProperty(kb, resource.getFrameID());
        FrameStore fs = resource.getOWLModel().getHeadFrameStore();
        Iterator frames = fs.getFramesWithAnyDirectOwnSlotValue(dummy).iterator();
        if (frames.hasNext()) {
            return resource.getOWLModel().getRDFPropertyClass();
        }
        return null;
    }


    public void patch(Iterator resources, String namespace) {
        OWLModel owlModel = null;
        TripleStore ts = null;
        while (resources.hasNext()) {
            RDFResource resource = (RDFResource) resources.next();
            if (namespace.equals(resource.getNamespace())) {
                if (owlModel == null) {
                    owlModel = resource.getOWLModel();
                    String uri = namespace;
                    if (uri.endsWith("#")) {
                        uri = uri.substring(0, uri.length() - 1);
                    }
                    ts = owlModel.getTripleStoreModel().createTripleStore(uri);
                }
                RDFSClass type = getRDFType(resource);
                if (type != null) {
                    ts.add(resource, owlModel.getRDFTypeProperty(), type);
                    resource.removeDirectType(owlModel.getRDFUntypedResourcesClass());
                    owlModel.getTripleStoreModel().setHomeTripleStore(resource, ts);
                }
            }
        }
    }
}
