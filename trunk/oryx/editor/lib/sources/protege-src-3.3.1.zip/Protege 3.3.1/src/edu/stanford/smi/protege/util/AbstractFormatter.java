/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;

import edu.stanford.smi.protege.model.Frame;

/**
 * TODO Class Comment
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public abstract class AbstractFormatter extends Formatter {
    private static final String lineSeparator = SystemUtilities.getLineSeparator();
    private static final DateFormat dateFormat = new StandardDateFormat();

    //ESCA-JAVA0130 
    protected String format(LogRecord record, String user, boolean showDate, boolean showMethod) {
        StringBuffer buffer = new StringBuffer();
        if (showDate) {
            buffer.append(getDateString());
            buffer.append(" ");
        }
        if (user != null) {
            buffer.append(user);
            buffer.append(" ");
        }
        Level level = record.getLevel();
        buffer.append(level.toString());
        buffer.append(": ");
        buffer.append(record.getMessage());
        Throwable throwable = record.getThrown();
        if (throwable == null) {
            String className = record.getSourceClassName();
            if (showMethod && className != null) {
                buffer.append(" -- ");
                buffer.append(StringUtilities.getShortClassName(className));
                buffer.append(".");
                buffer.append(record.getSourceMethodName());
                buffer.append("(");
                Object[] arguments = record.getParameters();
                if (arguments != null) {
                    for (int i = 0; i < arguments.length; ++i) {
                        if (i != 0) {
                            buffer.append(", ");
                        }
                        buffer.append(toString(arguments[i]));
                    }
                }
                buffer.append(")");
            }
        } else {
            buffer.append(" -- ");
            StringWriter writer = new StringWriter();
            throwable.printStackTrace(new PrintWriter(writer));
            buffer.append(writer.getBuffer());
        }
        buffer.append(lineSeparator);
        return buffer.toString();
    }

    protected static String getLineSeparator() {
        return lineSeparator;
    }

    protected static String getDateString() {
        return dateFormat.format(new Date());
    }

    protected static String toString(Object o) {
        String string;
        try {
            if (o == null) {
                string = null;
            } else if (o instanceof Collection) {
                string = "[" + CollectionUtilities.toString((Collection) o) + "]";
            } else if (o.getClass().isArray()) {
                string = "{" + CollectionUtilities.toString(Arrays.asList((Object[]) o)) + "}";
            } else if (o instanceof Frame) {
                string = ((Frame) o).getBrowserText();
            } else {
                string = o.toString();
            }
        } catch (Exception e) {
            string = "<<toString() exception>>";
        }
        return string;
    }

}
