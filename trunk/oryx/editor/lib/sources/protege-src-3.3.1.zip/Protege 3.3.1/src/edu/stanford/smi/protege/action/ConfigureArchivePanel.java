/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.action;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.table.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.resource.*;
import edu.stanford.smi.protege.util.*;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class ConfigureArchivePanel extends JPanel {
    private Project _currentProject;

    public ConfigureArchivePanel(Project project) {
        super(new BorderLayout());
        _currentProject = project;
        add(createExistingArchiveVersionsPanel(), BorderLayout.CENTER);
        add(createOptionsPanel(), BorderLayout.SOUTH);
    }

    private static JComponent createOptionsPanel() {
        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(createAutoArchivePanel());
        panel.add(createNumberOfArchivedVersionsPanel());
        return panel;
    }

    private static JComponent createAutoArchivePanel() {
        return new JCheckBox("Automatically archive the current version on Save");
    }

    private static JComponent createNumberOfArchivedVersionsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.add(ComponentFactory.createLabel("Maximum number of archived versions"));
        panel.add(new JTextField(5));
        return panel;
    }

    private JComponent createExistingArchiveVersionsPanel() {
        JTable table = new JTable(); // ComponentFactory.createTable(null);
        table.setModel(createTableModel());
        LabeledComponent c = new LabeledComponent("Archived Versions", ComponentFactory.createScrollPane(table));
        c.addHeaderButton(createDeleteVersionButton());
        return c;
    }

    private static Action createDeleteVersionButton() {
        return new AbstractAction("Delete Selected Version", Icons.getDeleteIcon()) {
            public void actionPerformed(ActionEvent event) {
                Log.getLogger().info("delete selected version");
            }
        };
    }

    private TableModel createTableModel() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Date and Time");
        model.addColumn("Comment");
        Iterator i = ArchiveManager.getArchiveManager().getArchiveRecords(_currentProject).iterator();
        while (i.hasNext()) {
            ArchiveRecord record = (ArchiveRecord) i.next();
            Date timestamp = record.getTimestamp();
            String comment = record.getComment();
            model.addRow(new Object[] { timestamp, comment });
        }
        return model;
    }
}
