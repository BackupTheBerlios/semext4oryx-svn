/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.model.framestore;

import java.lang.reflect.*;
import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.model.query.Query;
import edu.stanford.smi.protege.model.query.QueryCallback;
import edu.stanford.smi.protege.util.*;

public class TraceFrameStoreHandler extends AbstractFrameStoreInvocationHandler {
    private Map<Method, Integer> methodCounts = new HashMap<Method, Integer>();
    private static Method executeQueryMethod;
    static {
      try {
        executeQueryMethod 
          = FrameStore.class.getMethod("executeQuery", 
                                       new Class[] {Query.class, QueryCallback.class});
      } catch (Exception e) {
        Log.getLogger().warning("Non-fatal Problem encountered finding executeQuery method - contact developers");
      }
    }
    
    public Object handleInvoke(Method m, Object[] args) {
        Object o = invoke(m, args);
        trace(m, args);
        return o;
    }
    
    @Override
    protected void executeQuery(Query q, QueryCallback qc) {
      getDelegate().executeQuery(q, qc);
      Integer next = updateMethodCount(executeQueryMethod);
      print(next, executeQueryMethod, new Object[] {q, qc});
    }

    private void trace(Method method, Object[] args) {
        Integer next = updateMethodCount(method);
        print(next.intValue(), method, args);
    }
    
    private Integer updateMethodCount(Method method) {
      Integer current = (Integer) methodCounts.get(method);
      Integer next = (current == null) ? new Integer(1) : new Integer(current.intValue() + 1);
      methodCounts.put(method, next);
      return next;
    }

    public static void print(int next, Method method, Object[] args) {
        Log.getLogger().info(next + " " + method.getName() + " " + argString(args));
    }

    private static String argString(Object[] args) {
        StringBuffer buffer = new StringBuffer();
        if (args != null) {
            for (int i = 0; i < args.length; ++i) {
                Object o = args[i];
                if (o instanceof Frame) {
                    o = ((Frame) o).getFrameID();
                }
                buffer.append(o);
                buffer.append(" ");
            }
        }
        return buffer.toString();
    }


}
