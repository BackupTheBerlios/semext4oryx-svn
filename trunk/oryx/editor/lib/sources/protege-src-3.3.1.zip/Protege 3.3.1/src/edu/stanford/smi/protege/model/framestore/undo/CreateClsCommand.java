/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.model.framestore.undo;

import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.model.framestore.*;

class CreateClsCommand extends AbstractCommand {
    private Cls createdCls;
    private FrameID id;
    private String name;
    private Collection types;
    private Collection superclasses;
    private boolean loadDefaults;

    CreateClsCommand(FrameStore delegate, FrameID id, String name, Collection types, Collection superclasses,
            boolean loadDefaults) {
        super(delegate);
        this.id = id;
        this.name = name;
        this.types = new ArrayList(types);
        this.superclasses = new ArrayList(superclasses);
        this.loadDefaults = loadDefaults;
    }

    public Object doIt() {
        createdCls = getDelegate().createCls(id, name, types, superclasses, loadDefaults);
        name = getDelegate().getFrameName(createdCls);
        id = createdCls.getFrameID();
        setDescription("Create class " + getText(createdCls));
        return createdCls;
    }

    public void undoIt() {
        getDelegate().deleteCls(createdCls);
        createdCls.markDeleted(true);
    }

    public void redoIt() {
        getDelegate().createCls(id, name, types, superclasses, loadDefaults);
        createdCls.markDeleted(false);
    }
}