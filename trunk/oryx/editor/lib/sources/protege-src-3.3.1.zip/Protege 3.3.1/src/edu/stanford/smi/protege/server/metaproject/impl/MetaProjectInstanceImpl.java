/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.server.metaproject.impl;

import java.io.File;
import java.io.Serializable;
import java.util.Set;

import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.server.metaproject.GroupAndOperation;
import edu.stanford.smi.protege.server.metaproject.MetaProjectInstance;
import edu.stanford.smi.protege.server.metaproject.MetaProject.ClsEnum;
import edu.stanford.smi.protege.server.metaproject.MetaProject.SlotEnum;

public class MetaProjectInstanceImpl extends WrappedProtegeInstanceImpl
		implements MetaProjectInstance, Serializable {
	private static final long serialVersionUID = 8666270295698053695L;

	String name;

	String location;

	Set<GroupAndOperation> operations;

	@SuppressWarnings("unchecked")
	protected MetaProjectInstanceImpl(MetaProjectImpl mp, Instance pi) {
		super(mp, pi, ClsEnum.Project);
		location = (String) pi.getOwnSlotValue(mp.getSlot(SlotEnum.location));
		localizeLocation(location);
		name = (String) pi.getOwnSlotValue(mp.getSlot(SlotEnum.name));
		operations = (Set<GroupAndOperation>) getSlotValues(
				SlotEnum.allowedGroupOperation, ClsEnum.GroupOperation);
	}

	public MetaProjectInstanceImpl(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public String getLocation() {
		return location;
	}

	private static String localizeLocation(String location) {
		if (File.separatorChar != '\\') {
			location = location.replace('\\', File.separatorChar);
		}
		return location;
	}

	public Set<GroupAndOperation> getAllowedGroupOperations() {
		return operations;
	}

	public boolean equals(Object o) {
		if (!(o instanceof MetaProjectInstance)) {
			return false;
		}
		MetaProjectInstance other = (MetaProjectInstance) o;
		return name.equals(other.getName());
	}

	public int hashCode() {
		return name.hashCode();
	}

	public String toString() {
		return name;
	}

	public void setLocation(String location) {
	    setSlotValue(SlotEnum.location, location);
	}

	public void setName(String name) {
	    setSlotValue(SlotEnum.name, name);
    }

}
