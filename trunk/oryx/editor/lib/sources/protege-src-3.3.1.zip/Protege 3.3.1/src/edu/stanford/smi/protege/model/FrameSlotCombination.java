/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.model;

import edu.stanford.smi.protege.util.*;

/**
 * A holder for a frame-slot pair.  This combination comes up often enought that this class is useful.  The particular
 * reason why the frame and the slot are being held together is not specified by this class but should be evident from
 * the use.  Typical reasons are things like "a facet override goes on a class-slot pair" or an "own slot value is from
 * a particular frame-slot pair".
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class FrameSlotCombination {
    private Frame _frame;
    private Slot _slot;

    public FrameSlotCombination(Frame frame, Slot slot) {
        this._frame = frame;
        this._slot = slot;
    }

    public boolean equals(Object o) {
        boolean equals = false;
        if (o instanceof FrameSlotCombination) {
            FrameSlotCombination other = (FrameSlotCombination) o;
            equals = equals(other._frame, _frame) && equals(other._slot, _slot);
        }
        return equals;
    }

    public static boolean equals(Object o1, Object o2) {
        return SystemUtilities.equals(o1, o2);
    }

    public Frame getFrame() {
        return _frame;
    }

    public Slot getSlot() {
        return _slot;
    }

    public int hashCode() {
        return _frame.hashCode() ^ _slot.hashCode();
    }
}
