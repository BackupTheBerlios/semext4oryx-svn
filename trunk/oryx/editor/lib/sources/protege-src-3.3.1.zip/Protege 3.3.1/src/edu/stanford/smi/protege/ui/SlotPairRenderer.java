/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.ui;

import java.util.*;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.resource.*;
import edu.stanford.smi.protege.util.*;

/**
 * Renderer for displaying a slot at a class. Has icons to indicate overrides.
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class SlotPairRenderer extends DefaultRenderer implements Cloneable {
    private static SlotPairRenderer _prototypeInstance = new SlotPairRenderer();

    public static SlotPairRenderer createInstance() {
        SlotPairRenderer result;
        try {
            result = (SlotPairRenderer) _prototypeInstance.clone();
        } catch (CloneNotSupportedException e) {
            Log.getLogger().warning(e.toString());
            result = _prototypeInstance;
        }
        return result;
    }

    public void load(Object value) {
        FrameSlotCombination combination = (FrameSlotCombination) value;
        Cls cls = (Cls) combination.getFrame();
        Slot slot = combination.getSlot();
        String text = slot.getBrowserText();
        boolean isInherited = !cls.hasDirectTemplateSlot(slot);
        boolean isReadonly = !cls.isEditable() || !slot.isEditable();
        boolean isOverridden = cls.hasDirectlyOverriddenTemplateSlot(slot);
        boolean isHidden = !slot.isVisible();
        Icon icon = Icons.getSlotIcon(isInherited, isOverridden, isReadonly, isHidden);
        setMainText(text);
        setMainIcon(icon);
        setBackgroundSelectionColor(Colors.getSlotSelectionColor());
    }

    public String getToolTipText() {
        FrameSlotCombination combination = (FrameSlotCombination) getValue();
        Cls cls = (Cls) combination.getFrame();
        Slot slot = combination.getSlot();
        StringBuffer buffer = new StringBuffer();
        appendInheritanceInformation(cls, slot, buffer);
        appendFacetOverrideInformation(cls, slot, buffer);
        String text;
        if (buffer.length() == 0) {
            text = null;
        } else {
            text = "<html>" + buffer.toString() + "</html>";
        }
        return text;
    }

    private static void appendInheritanceInformation(Cls cls, Slot slot, StringBuffer buffer) {
        if (!cls.hasDirectTemplateSlot(slot)) {
            buffer.append("<b>");
            buffer.append(slot.getBrowserText());
            buffer.append("</b> is inherited from ");
            boolean first = true;
            Iterator i = cls.getSuperclasses().iterator();
            while (i.hasNext()) {
                Cls superClass = (Cls) i.next();
                if (superClass.hasDirectTemplateSlot(slot)) {
                    if (!first) {
                        buffer.append(" and ");
                    }
                    buffer.append("<b>");
                    buffer.append(superClass.getBrowserText());
                    buffer.append("</b>");
                    first = false;
                }
            }
        }
    }

    private static void appendFacetOverrideInformation(Cls cls, Slot slot, StringBuffer buffer) {
        Collection facets = cls.getDirectlyOverriddenTemplateFacets(slot);
        if (!facets.isEmpty()) {
            if (buffer.length() != 0) {
                buffer.append("<br>");
            }
            Iterator i = facets.iterator();
            while (i.hasNext()) {
                Facet facet = (Facet) i.next();
                buffer.append("<b>");
                buffer.append(facet.getBrowserText());
                buffer.append("</b> is directly overridden");
                buffer.append("</br>");
            }
        }
    }

    public static void setPrototypeInstance(SlotPairRenderer renderer) {
        _prototypeInstance = renderer;
    }
}