/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.util;

import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;

import edu.stanford.smi.protege.model.*;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class ArchiveManager {

    private static final ArchiveManager THE_INSTANCE = new ArchiveManager();
    private static final DateFormat THE_FORMAT = new SimpleDateFormat("yyyy.MM.dd_HH.mm.ss");

    public static ArchiveManager getArchiveManager() {
        return THE_INSTANCE;
    }

    public static DateFormat getDateFormat() {
        return THE_FORMAT;
    }

    private ArchiveManager() {
        // do nothing    
    }

    //ESCA-JAVA0130 
    public void archive(Project p, String comment) {
        String name = p.getProjectName();
        File projectDir = getProjectDirectoryFile(p);
        File archiveDir = createArchiveDir(name, projectDir, new Date());
        File tempDir = getEmptyTempDir(name, archiveDir);
        moveProject(name, projectDir, tempDir);
        try {
            Collection errors = new ArrayList();
            p.save(errors);
            moveProject(name, projectDir, archiveDir);
            createComment(archiveDir, comment);
        } finally {
            moveProject(name, tempDir, projectDir);
            tempDir.delete();
        }
    }

    private static File getProjectDirectoryFile(Project p) {
        URI uri = p.getProjectURI();
        return (uri == null) ? null : new File(uri).getParentFile();
    }

    private static File createArchiveDir(String name, File projectDir, Date date) {
        File archiveDir = getArchiveDir(name, projectDir, date);
        archiveDir.mkdirs();
        return archiveDir;
    }

    private static File getArchiveDir(String name, File projectDir, Date date) {
        File mainArchiveDir = getMainArchiveDir(name, projectDir);
        return new File(mainArchiveDir, getTimestamp(date));
    }

    private static File getMainArchiveDir(String name, File projectDir) {
        File mainArchiveDir = new File(projectDir, name + ".parc");
        mainArchiveDir.mkdir();
        return mainArchiveDir;
    }

    private static void moveProject(String projectName, File sourceDir, File targetDir) {
        File[] files = sourceDir.listFiles();
        if (files != null) {
            for (int i = 0; i < files.length; ++i) {
                File sourceFile = files[i];
                if (sourceFile.isFile()) {
                    String sourceFileName = sourceFile.getName();
                    if (sourceFileName.startsWith(projectName)) {
                        File targetFile = new File(targetDir, sourceFileName);
                        sourceFile.renameTo(targetFile);
                    }
                }
            }
        }
    }

    private static File getEmptyTempDir(String projectName, File archiveDir) {
        File tempDir = new File(archiveDir, "temp");
        boolean created = tempDir.mkdir();
        if (!created) {
            File[] files = tempDir.listFiles();
            if (files != null) {
                for (int i = 0; i < files.length; ++i) {
                    files[i].delete();
                }
            }
        }
        return tempDir;
    }

    //ESCA-JAVA0130 
    public Collection getArchiveRecords(Project p) {
        Collection records = new ArrayList();
        File[] file = getMainArchiveDir(p.getProjectName(), getProjectDirectoryFile(p)).listFiles();
        for (int i = 0; i < file.length; ++i) {
            records.add(new ArchiveRecord(file[i], getComment(file[i])));
        }
        return records;
    }

    //ESCA-JAVA0130 
    public Project revertToVersion(Project p, Date date) {
        Project revertedProject = null;
        String name = p.getProjectName();
        File projectDir = getProjectDirectoryFile(p);
        File archiveDir = getArchiveDir(name, projectDir, date);
        File tempDir = getEmptyTempDir(name, archiveDir);
        moveProject(name, projectDir, tempDir);
        moveProject(name, archiveDir, projectDir);
        try {
            Collection errors = new ArrayList();
            revertedProject = Project.loadProjectFromURI(p.getProjectURI(), errors);
        } finally {
            moveProject(name, projectDir, archiveDir);
            moveProject(name, tempDir, projectDir);
            tempDir.delete();
        }
        return revertedProject;
    }

    private static String getTimestamp(Date date) {
        return THE_FORMAT.format(date);
    }

    private static String getComment(File directory) {
        String comment = null;
        File file = getCommentFile(directory);
        if (file != null) {
            try {
                BufferedReader reader = FileUtilities.createBufferedReader(file);
                comment = reader.readLine();
                reader.close();
            } catch (Exception e) {
                // do nothing
            }
        }
        return comment;
    }

    private static File getCommentFile(File directory) {
        return new File(directory, "comment.txt");
    }

    private static void createComment(File directory, String comment) {
        if (comment != null && comment.length() > 0) {
            File file = getCommentFile(directory);
            try {
                PrintWriter pw = FileUtilities.createPrintWriter(file, false);
                pw.println(comment);
                pw.close();
            } catch (Exception e) {
                Log.getLogger().warning(e.toString());
            }
        }
    }
}
