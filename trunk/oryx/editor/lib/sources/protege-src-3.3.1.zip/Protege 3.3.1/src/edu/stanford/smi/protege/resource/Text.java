/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.resource;

import java.io.*;
import java.net.*;
import java.util.*;

import edu.stanford.smi.protege.util.*;

/**
 * Utility class for accessing assorted text strings.
 *
 * @author Ray Fergerson
 * @author Jennifer Vendetti
 */
public final class Text {
    private static String buildFile = "build.properties";
    private static String directory = "files";
    private static Properties props;
    private static final String PROGRAM_NAME = "Prot\u00E9g\u00E9";
    private static final String PROGRAM_ASCII_NAME = "Protege";
    public static final String PROGRAM_NAME_PROPERTY = "resource.text.program_name";

    static {
        try {
            props = new Properties();
            InputStream stream = FileUtilities.getResourceStream(Text.class, directory, buildFile);
            props.load(stream);
        } catch (IOException e) {
            Log.getLogger().severe(Log.toString(e));
        }
    }

    public static String getBuildInfo() {
        return "Build " + getBuildNumber();
    }

    public static String getProgramName() {
        return SystemUtilities.getSystemProperty(PROGRAM_NAME_PROPERTY, PROGRAM_NAME);
    }

    public static String getProgramTextName() {
        return SystemUtilities.getSystemProperty(PROGRAM_NAME_PROPERTY, PROGRAM_ASCII_NAME);
    }

    public static String getProgramNameAndVersion() {
        return getProgramName() + " " + getVersion() + " " + getStatus();
    }

    public static String getBuildNumber() {
        return props.getProperty("build.number", "?");
    }

    public static String getStatus() {
        return props.getProperty("build.status");
    }

    public static String getVersion() {
        return props.getProperty("build.version", "?");
    }

    public static URL getAboutURL() {
        return Text.class.getResource("files/about.html");
    }
}
