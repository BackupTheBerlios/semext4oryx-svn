/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.ui;

import java.awt.*;
import java.net.*;

import javax.swing.*;

import edu.stanford.smi.protege.resource.*;
import edu.stanford.smi.protege.util.*;

/**
 * Panel to display for the "About Box" menu item.
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class AboutBox extends JPanel {

    public AboutBox() {
        setLayout(new BorderLayout());
        URL url = Text.getAboutURL();
        JEditorPane pane = ComponentFactory.createHTMLBrowser(url);
        substitute(pane);

        add(new JScrollPane(pane));
        pane.setEditable(false);
        setPreferredSize(new Dimension(535, 550));
    }

    private static void substitute(JEditorPane pane) {
        String text = getText(pane);
        text = replace(text, "{0}", Text.getVersion());
        text = replace(text, "{1}", Text.getBuildInfo());
        pane.setText(text);
    }

    // The pane loads asynchronously so we have to wait...
    private static String getText(JEditorPane pane) {
        String text = null;
        for (int i = 0; i < 100; ++i) {
            text = pane.getText();
            if (text.indexOf("Stanford") != -1 && text.indexOf("</html>") != -1) {
                break;
            }
            SystemUtilities.sleepMsec(100);
        }
        SystemUtilities.sleepMsec(100);
        return text;
    }

    private static String replace(String text, String macro, String replaceString) {
        return StringUtilities.replace(text, macro, replaceString);
    }
}