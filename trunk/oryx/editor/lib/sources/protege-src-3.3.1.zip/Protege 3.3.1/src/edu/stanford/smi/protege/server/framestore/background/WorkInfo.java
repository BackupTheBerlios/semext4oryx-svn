/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.server.framestore.background;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;

import edu.stanford.smi.protege.model.Frame;
import edu.stanford.smi.protege.server.RemoteSession;

public class WorkInfo implements Comparable<WorkInfo> {
  private static int counter = 0;
  
  private RemoteSession client;
  private Frame frame;
  private Set<ServerCachedState> states = new HashSet<ServerCachedState>();
  private EnumSet<CacheRequestReason> reasons = EnumSet.noneOf(CacheRequestReason.class);
  private boolean skipDirectInstances = false;
  private boolean targetFullCache = true;
  
  private int sequence = counter++;
  
  public RemoteSession getClient() {
    return client;
  }
  
  public void setClient(RemoteSession client) {
    this.client = client;
  }
  
  public void addState(ServerCachedState state) {
    states.add(state);
  }
  
  public Set<ServerCachedState> getStates() {
    return states;
  }
  
  public void addReason(CacheRequestReason reason) {
    reasons.add(reason);
  }
  
  public EnumSet<CacheRequestReason> getReasons() {
    return reasons;
  }
  
  public boolean skipDirectInstances() {
    return skipDirectInstances;
  }

  public void setSkipDirectInstances(boolean skipDirectInstances) {
    this.skipDirectInstances = skipDirectInstances;
  }
  
  public int getSequence() {
    return sequence;
  }
  
  public void setNewest() {
    sequence = counter++;
  }

  public int compareTo(WorkInfo other) {
    int myPriority = CacheRequestReason.priority(reasons);
    int otherPriority = CacheRequestReason.priority(other.reasons);
    if (myPriority != otherPriority) {
      return otherPriority - myPriority;
    }
    return other.sequence - sequence;
  }

  public Frame getFrame() {
    return frame;
  }

  public void setFrame(Frame frame) {
    this.frame = frame;
  }

  public boolean isTargetFullCache() {
    return targetFullCache;
  }

  public void setTargetFullCache(boolean targetFullCache) {
    this.targetFullCache = targetFullCache;
  }
  
  public ClientAndFrame getClientAndFrame() {
    return new ClientAndFrame(client, frame);
  }
}