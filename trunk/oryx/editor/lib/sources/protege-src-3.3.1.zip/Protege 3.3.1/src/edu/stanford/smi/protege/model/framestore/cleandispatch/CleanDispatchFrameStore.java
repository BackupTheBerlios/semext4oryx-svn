/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.model.framestore.cleandispatch;

import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.model.framestore.*;

public class CleanDispatchFrameStore extends FrameStoreAdapter {
    private Map _slotToDispatchMap = new HashMap();
    private Dispatch _defaultDispatch;

    public void setDelegate(FrameStore frameStore) {
        super.setDelegate(frameStore);
        _slotToDispatchMap.clear();
        if (frameStore != null) {
            loadDispatches();
        }
    }

    public void close() {
        _slotToDispatchMap = null;
        _defaultDispatch = null;
    }
    
    public List getDirectOwnSlotValues(Frame frame, Slot slot) {
        return getDispatch(slot).getDirectOwnSlotValues(getDelegate(), frame, slot);
    }

    public void setDirectOwnSlotValues(Frame frame, Slot slot, Collection values) {
        getDispatch(slot).setDirectOwnSlotValues(getDelegate(), frame, slot, values);
    }

    private void addDispatch(String slotName, Dispatch dispatch) {
        Slot slot = (Slot) getDelegate().getFrame(slotName);
        _slotToDispatchMap.put(slot, dispatch);
    }

    private void loadDispatches() {
        _defaultDispatch = new DefaultDispatch();
        addDispatch(Model.Slot.NAME, new NameDispatch());
        addDispatch(Model.Slot.DIRECT_INSTANCES, new DirectInstancesDispatch());
        addDispatch(Model.Slot.DIRECT_TYPES, new DirectTypesDispatch());
        addDispatch(Model.Slot.DIRECT_SUBCLASSES, new DirectSubclassesDispatch());
        addDispatch(Model.Slot.DIRECT_SUPERCLASSES, new DirectSuperclassesDispatch());
        addDispatch(Model.Slot.DIRECT_SUBSLOTS, new DirectSubslotsDispatch());
        addDispatch(Model.Slot.DIRECT_SUPERSLOTS, new DirectSuperslotsDispatch());
        addDispatch(Model.Slot.DIRECT_TEMPLATE_SLOTS, new DirectTemplateSlotsDispatch());
        addDispatch(Model.Slot.DIRECT_DOMAIN, new DirectDomainDispatch());
    }

    private Dispatch getDispatch(Slot slot) {
        Dispatch dispatch = (Dispatch) _slotToDispatchMap.get(slot);
        if (dispatch == null) {
            dispatch = _defaultDispatch;
        }
        return dispatch;
    }
}
