/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.ui;

import java.util.*;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.resource.*;
import edu.stanford.smi.protege.util.*;

/**
 * Implementation of Finder that will work on a generic JList.
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class ListFinder extends Finder {
    private JList _list;

    public ListFinder(JList list, ResourceKey key) {
        super(key);
        _list = list;
    }
    public ListFinder(JList list, String description, Icon icon) {
        super(description, icon);
        _list = list;
    }

    public ListFinder(JList list, String description) {
        this(list, description, Icons.getFindIcon());
    }

    protected int getBestMatch(List matches, String text) {
        return 0;
    }

    protected List getMatches(String text, int maxMatches) {
        if (!text.endsWith("*")) {
            text += "*";
        }

        StringMatcher matcher = new SimpleStringMatcher(text);
        List matchingInstances = new ArrayList();
        ListModel model = _list.getModel();
        int size = model.getSize();
        for (int i = 0; i < size; ++i) {
            Instance instance = (Instance) model.getElementAt(i);
            String browserText = instance.getBrowserText().toLowerCase();
            if (matcher.isMatch(browserText)) {
                matchingInstances.add(instance);
            }
        }
        return matchingInstances;
    }

    protected void select(Object o) {
        _list.setSelectedValue(o, true);
    }
}
