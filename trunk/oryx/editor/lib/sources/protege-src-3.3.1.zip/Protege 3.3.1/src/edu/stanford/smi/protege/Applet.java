/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege;

import java.awt.*;
import java.awt.event.*;
import java.net.*;

import javax.swing.*;

import edu.stanford.smi.protege.resource.*;
import edu.stanford.smi.protege.util.*;

/**
 * Class to allow Protege to run as an applet. This is used mostly for demos.
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class Applet extends JApplet {

    private String getProjectName() {
        return getParameter("project_name");
    }

    private URL getProjectURL() {
        URL url = null;
        try {
            url = new URL(getDocumentBase(), getProjectName());
        } catch (MalformedURLException e) {
            Log.getLogger().severe(Log.toString(e));
        }
        return url;
    }

    public void init() {
        try {
            SystemUtilities.initGraphics();
            SystemUtilities.setApplet(true);
            URL projectURL = getProjectURL();
            setup(projectURL);
        } catch (Exception e) {
            Log.getLogger().severe(Log.toString(e));
            SystemUtilities.pause();
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.getContentPane().setLayout(new BorderLayout());
        Applet applet = new Applet();
        frame.getContentPane().add(applet);
        applet.setup(getURL(args));
        frame.pack();
        frame.setVisible(true);
    }

    private static URL getURL(String[] args) {
        URL url = null;
        try {
            url = new URL(args[0]);
        } catch (MalformedURLException e) {
            Log.getLogger().severe(Log.toString(e));
        }
        return url;
    }

    private void setup(final URL projectURL) {
        JButton button = new JButton(Icons.getLogoBannerIcon());
        button.setFocusPainted(false);
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                String[] args;
                if (projectURL == null) {
                    args = new String[0];
                } else {
                    args = new String[] { projectURL.toString() };
                }
                Application.main(args);
            }
        });
        getContentPane().add(button);
    }
}