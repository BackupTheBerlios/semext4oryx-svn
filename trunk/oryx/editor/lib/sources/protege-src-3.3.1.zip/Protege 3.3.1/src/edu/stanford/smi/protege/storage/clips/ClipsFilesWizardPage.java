/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.storage.clips;

import java.awt.*;

import javax.swing.*;
import javax.swing.event.*;

import edu.stanford.smi.protege.util.*;

/**
 * TODO Class Comment
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class ClipsFilesWizardPage extends WizardPage {
    private FileField clsesFileField;
    private FileField instancesFileField;
    private ClipsFilesPlugin plugin;

    public ClipsFilesWizardPage(Wizard wizard, ClipsFilesPlugin plugin) {
        super("clips files", wizard);
        this.plugin = plugin;
        createComponents();
        layoutComponents();
        updateSetPageComplete();
    }

    private void createComponents() {
        clsesFileField = new FileField("Classes (.pont) File", null, ".pont", "Classes File");
        instancesFileField = new FileField("Instances (.pins) File", null, ".pins", "Instances File");

        clsesFileField.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                onClsFieldChanged();
                updateSetPageComplete();
            }
        });
    }

    private void onClsFieldChanged() {
        String name = getClsesFileName();
        String instancesName = FileUtilities.replaceExtension(name, ".pins");
        instancesFileField.setPath(instancesName);
    }

    private void updateSetPageComplete() {
        setPageComplete(getClsesFileName() != null);
    }

    private void layoutComponents() {
        setLayout(new BorderLayout());
        Box panel = Box.createVerticalBox();
        panel.add(clsesFileField);
        panel.add(instancesFileField);
        add(panel, BorderLayout.NORTH);
    }

    public void onFinish() {
        String clsesFileName = getClsesFileName();
        String instancesFileName = getInstancesFileName();
        plugin.setFiles(clsesFileName, instancesFileName);
    }

    private String getClsesFileName() {
        return getPath(clsesFileField, ".pont");
    }

    private String getInstancesFileName() {
        return getPath(instancesFileField, ".pins");
    }

    private static String getPath(FileField field, String extension) {
        String path = field.getPath();
        return FileUtilities.ensureExtension(path, extension);
    }

    public WizardPage getNextPage() {
        WizardPage page;
        if (plugin instanceof ClipsFilesCreateProjectPlugin) {
            ClipsFilesCreateProjectPlugin createPlugin = (ClipsFilesCreateProjectPlugin) plugin;
            page = new IncludedProjectsWizardPage(getWizard(), createPlugin);
        } else {
            page = super.getNextPage();
        }
        return page;
    }
}
