/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.server.metaproject.impl;

import java.util.HashSet;
import java.util.Set;

import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protege.server.metaproject.MetaProject.ClsEnum;
import edu.stanford.smi.protege.server.metaproject.MetaProject.SlotEnum;

public class WrappedProtegeInstanceImpl {
  MetaProjectImpl mp;
  private Instance i;
  private ClsEnum cls;
  
  public WrappedProtegeInstanceImpl() {
    
  }
  
  public WrappedProtegeInstanceImpl(MetaProjectImpl mp, Instance i, ClsEnum cls) {
    if (!i.hasType(mp.getCls(cls))) {
      throw new IllegalArgumentException("" + i + " should be of type " + cls);
    }
    this.i = i;
    this.cls = cls;
    this.mp = mp;
  }
  
  public MetaProjectImpl getMetaProject() {
    return mp;
  }
  
  public Instance getProtegeInstance() {
    return i;
  }

  public ClsEnum getCls() {
    return cls;
  }
  
  @SuppressWarnings("unchecked")
  protected Set getSlotValues(SlotEnum slot, ClsEnum rangeCls) {
    Set results = new HashSet();
    for (Object o : i.getOwnSlotValues(mp.getSlot(slot))) {
      results.add(mp.wrapInstance(rangeCls, (Instance) o));
    }
    return results;
  }
  
  protected void setSlotValue(SlotEnum slot, Object value) {
      Slot protege_slot = mp.getSlot(slot);
      i.setDirectOwnSlotValue(protege_slot, value);
  }
  
  public boolean equals(Object o) {
    if (!(o instanceof WrappedProtegeInstanceImpl)) {
      return false;
    }
    WrappedProtegeInstanceImpl other = (WrappedProtegeInstanceImpl) o;
    return mp == other.mp && getProtegeInstance().equals(other.getProtegeInstance());
  }
  
  public int hashCode() {
    return getProtegeInstance().hashCode();
  }
  
}
