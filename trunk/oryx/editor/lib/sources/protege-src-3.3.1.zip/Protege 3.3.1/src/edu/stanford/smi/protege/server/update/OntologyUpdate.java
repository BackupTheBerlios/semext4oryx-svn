/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.server.update;

import java.io.Serializable;
import java.util.List;

import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Localizable;
import edu.stanford.smi.protege.util.LocalizeUtils;

/**
 * When a client asks for a set of values, this structure includes
 * both the values calculated and the events that tell the client how
 * to update his cache.
 * 
 * @author tredmond
 *
 */
public class OntologyUpdate implements Serializable, Localizable {

  private List<ValueUpdate> updates;
  
  /**
   * 
   * @return the latest events which the client can use to update its cache.
   */
  public List<ValueUpdate> getValueUpdates() {
    return updates;
  }


  /**
   * 
   * @param values the values the user selected
   * @param events the latest events which the client can use to update its cache.
   */
  public OntologyUpdate(List<ValueUpdate> updates) {
    this.updates = updates;
  }


  public void localize(KnowledgeBase kb) {
     LocalizeUtils.localize(updates, kb);
  }

  /* Unable to figure how to avoid the EOF Exception and 
     the ClassNotFoundException.
     I think  what is happening in the first  case is that the 
     reader is trying to read too fast.
     The second case almost worked but maybe there  was  a problem
     wiht the classloader?
  
  private void writeObject(ObjectOutputStream out)
  throws IOException {
    GZIPOutputStream zipOut = new GZIPOutputStream(out);
    ObjectOutputStream zipObjectOut = new ObjectOutputStream(zipOut);
    zipObjectOut.writeObject(updates);
    zipObjectOut.flush();
    zipOut.finish();
  }
  
  private void readObject(ObjectInputStream in)
  throws IOException, ClassNotFoundException {
    GZIPInputStream zipIn = new GZIPInputStream(in);
    ObjectInputStream zipObjectIn = new ObjectInputStream(zipIn);
    updates = (List) zipObjectIn.readObject();
  }

  */

}
