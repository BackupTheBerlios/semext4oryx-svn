/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.model;

import java.util.*;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public interface FrameFactory {
    void addJavaPackage(String packageName);

    void removeJavaPackage(String packageName);

    Cls createCls(FrameID id, Collection directTypes);

    Slot createSlot(FrameID id, Collection directTypes);

    Facet createFacet(FrameID id, Collection directTypes);

    SimpleInstance createSimpleInstance(FrameID id, Collection directTypes);

    boolean isCorrectJavaImplementationClass(FrameID id, Collection directTypes, Class clas);

    /**
     * @return integer to map this frame to a Java class. This integer may then be passed in later
     * to the createFrameFromClassId method
     */
    int getJavaClassId(Frame value);

    /**
     * @return frame appropriate for this java class id.
     */
    Frame createFrameFromClassId(int javaClassId, FrameID id);

    /**
     * @return all java class ids which correspond to classes.  
     * The collection contains java.lang.Integer objects.
     */
    Collection getClsJavaClassIds();

    /**
     * @return all java class ids which correspond to slots
     */
    Collection getSlotJavaClassIds();

    /**
     * @return all java class ids which correspond to facets
     */
    Collection getFacetJavaClassIds();

    /**
     * @return all java class ids which correspond to simple instances
     */
    Collection getSimpleInstanceJavaClassIds();
}