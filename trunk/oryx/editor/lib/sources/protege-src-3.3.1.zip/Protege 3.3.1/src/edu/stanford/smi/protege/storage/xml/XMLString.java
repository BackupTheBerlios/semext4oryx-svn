/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.storage.xml;
//ESCA*JAVA0257

/**
 * TODO Class Comment
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public interface XMLString {

    String NAMESPACE = "http://protege.stanford.edu/xml";
    String SCHEMA_LOCATION = "http://protege.stanford.edu/xml/schema/protege.xsd";

    interface ElementName {
        String KNOWLEDGE_BASE = "knowledge_base";
        String CLASS = "class";
        String SLOT = "slot";
        String FACET = "facet";
        String SIMPLE_INSTANCE = "simple_instance";
        String NAME = "name";
        String TYPE = "type";
        String SUPERCLASS = "superclass";
        String SUPERSLOT = "superslot";
        String TEMPLATE_SLOT = "template_slot";
        String OWN_SLOT_VALUE = "own_slot_value";
        String TEMPLATE_FACET_VALUE = "template_facet_value";
        String SLOT_REFERENCE = "slot_reference";
        String FACET_REFERENCE = "facet_reference";
        String VALUE = "value";
    }

    interface AttributeName {
        String VALUE_TYPE = "value_type";
    }

    interface AttributeValue {
        String CLASS_TYPE = "class";
        String SLOT_TYPE = "slot";
        String FACET_TYPE = "facet";
        String SIMPLE_INSTANCE_TYPE = "simple_instance";
        String STRING_TYPE = "string";
        String INTEGER_TYPE = "integer";
        String FLOAT_TYPE = "float";
        String BOOLEAN_TYPE = "boolean";
    }
}
