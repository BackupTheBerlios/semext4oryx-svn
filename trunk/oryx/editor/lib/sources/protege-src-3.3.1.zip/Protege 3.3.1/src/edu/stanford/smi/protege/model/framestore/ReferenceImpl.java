/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.model.framestore;

import java.io.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;

public class ReferenceImpl implements Reference, Serializable, Localizable {
    private Frame _frame;
    private Slot _slot;
    private Facet _facet;
    private boolean _isTemplate;
    private int _hashCode;

    public ReferenceImpl(Frame frame, Slot slot, Facet facet, boolean isTemplate) {
        set(frame, slot, facet, isTemplate);
    }

    public ReferenceImpl() {
    }

    public void replace(Frame frame) {
        if (frame.equals(_frame)) {
            _frame = frame;
        } else if (frame.equals(_slot)) {
            _slot = (Slot) frame;
        } else if (frame.equals(_facet)) {
            _facet = (Facet) frame;
        }
    }

    public void set(Frame frame, Slot slot, Facet facet, boolean isTemplate) {
        if (frame == null) {
            throw new RuntimeException("null frame");
        } else if (slot == null) {
            throw new RuntimeException("null slot");
        }
        _frame = frame;
        _slot = slot;
        _facet = facet;
        _isTemplate = isTemplate;
        _hashCode = HashUtils.getHash(frame, slot, facet, isTemplate);
    }

    public Frame getFrame() {
        return _frame;
    }

    public Slot getSlot() {
        return _slot;
    }

    public Facet getFacet() {
        return _facet;
    }

    public String toString() {
        return "Reference(" + _frame + ", " + _slot + ", " + _facet + ")";
    }

    public boolean isTemplate() {
        return _isTemplate;
    }

    public boolean equals(Object o) {
        ReferenceImpl rhs = (ReferenceImpl) o;
        return equals(_frame, rhs._frame) && equals(_slot, rhs._slot) && equals(_facet, rhs._facet)
                && _isTemplate == rhs._isTemplate;
    }

    public static boolean equals(Object o1, Object o2) {
        return SystemUtilities.equals(o1, o2);
    }

    public int hashCode() {
        return _hashCode;
    }

    public boolean usesFrame(Frame frame) {
        return frame.equals(_frame) || frame.equals(_slot) || frame.equals(_facet);
    }

    public void localize(KnowledgeBase kb) {
        LocalizeUtils.localize(_frame, kb);
        LocalizeUtils.localize(_slot, kb);
        LocalizeUtils.localize(_facet, kb);
    }
}