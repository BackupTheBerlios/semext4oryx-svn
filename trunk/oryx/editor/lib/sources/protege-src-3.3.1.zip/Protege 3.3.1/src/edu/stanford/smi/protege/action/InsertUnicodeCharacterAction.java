/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.action;

import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.*;
import javax.swing.text.*;

import com.catalysoft.swing.unicode.*;

import edu.stanford.smi.protege.resource.*;
import edu.stanford.smi.protege.util.*;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 * @author Tania Tudorache <tudorache@stanford.edu>
 */
public class InsertUnicodeCharacterAction extends TextAction {
    private UnicodeChooser chooser;

    public InsertUnicodeCharacterAction() {
        super(null);
        StandardAction.initialize(this, ResourceKey.INSERT_UNICODE_ACTION, false);
    }

    public void actionPerformed(ActionEvent event) {
        final JTextComponent textComponent = getTextComponent(event);
        if (textComponent != null) {
	        if (chooser == null) {
	            Window window = SwingUtilities.windowForComponent(textComponent);
	            if (window == null) {
	                Log.getLogger().warning("no window for unicode panel");
	            } 
	            try {
	            	chooser = UnicodeChooser.instance(window);	
				} catch (RuntimeException e) {
					Log.getLogger().warning(e.getMessage());
				}	                        
	        }
	        
	        chooser.setVisible(true);
	        
			chooser.addPropertyChangeListener(new PropertyChangeListener() {
				public void propertyChange(PropertyChangeEvent evt) {
					// This check is currently not necessary as only one property change occurs,
					// but it is good practice anyway
					if (UnicodeChooser.INSERT_CHARACTER_PROPERTY.equals(evt.getPropertyName())) {
						Character symbol = (Character) evt.getNewValue();
						if (symbol != null) {
							try {
								textComponent.getDocument().insertString(textComponent.getCaretPosition(), symbol.toString(), null);
							} catch (BadLocationException e) {								
								 // do nothing
							}
						}
					}
				}
	        });	    
        }
    }
}
