/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.server.framestore;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.logging.Level;
import java.util.logging.Logger;

import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.framestore.AbstractFrameStoreInvocationHandler;
import edu.stanford.smi.protege.model.framestore.FrameStore;
import edu.stanford.smi.protege.model.query.Query;
import edu.stanford.smi.protege.model.query.QueryCallback;
import edu.stanford.smi.protege.util.LocalizeUtils;
import edu.stanford.smi.protege.util.Log;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class LocalizeFrameStoreHandler extends AbstractFrameStoreInvocationHandler {
    private static transient Logger log = Log.getLogger(LocalizeFrameStoreHandler.class);
    private int counter = 0;
    
    private KnowledgeBase _kb;

    public LocalizeFrameStoreHandler(KnowledgeBase kb) {
        if (log.isLoggable(Level.FINE)) {
          log.fine("Entering the Localize constructor");
        }
        _kb = kb;
    }

    protected Object handleInvoke(Method method, Object[] args) {
        if (log.isLoggable(Level.FINE)) {
          log.fine("Received Remote Invocation of " + method);
          log.fine("Count = " + (++counter));
        }
        localize(args);
        return invoke(method, args);
    }
    
    @Override
    protected void executeQuery(Query q, QueryCallback qc) {
      q.localize(_kb);
      LocalizeUtils.localize(qc, _kb);
      getDelegate().executeQuery(q, qc);
    }

    private void localize(Object[] args) {
        if (args != null) {
            for (int i = 0; i < args.length; ++i) {
                Object o = args[i];
                LocalizeUtils.localize(o, _kb);
            }
        }
    }

    public FrameStore newFrameStore() {
        ClassLoader loader = getClass().getClassLoader();
        Class[] classes = new Class[] { FrameStore.class };
        return (FrameStore) Proxy.newProxyInstance(loader, classes, this);
    }


}
