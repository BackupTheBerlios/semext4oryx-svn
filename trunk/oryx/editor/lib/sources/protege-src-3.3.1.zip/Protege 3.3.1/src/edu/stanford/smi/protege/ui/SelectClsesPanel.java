/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.ui;

import java.awt.*;
import java.util.*;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;

/**
 * Panel to allow a user to pick one or more classes.
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class SelectClsesPanel extends JComponent implements Validatable {
    private JTree _tree;
    private boolean _allowsMultiple;

    public SelectClsesPanel(KnowledgeBase kb) {
        this(kb, Collections.EMPTY_SET);
    }

    public SelectClsesPanel(KnowledgeBase kb, DefaultRenderer renderer) {
        this(kb, Collections.EMPTY_SET);
        _tree.setCellRenderer(renderer);
    }

    public SelectClsesPanel(KnowledgeBase kb, Collection clses) {
        this(kb, clses, true);
    }

    public SelectClsesPanel(KnowledgeBase kb, Collection clses, boolean allowsMultiple) {
        _allowsMultiple = allowsMultiple;
        if (clses.isEmpty()) {
            clses = kb.getRootClses();
        }
        _tree = ComponentFactory.createSelectableTree(ModalDialog.getCloseAction(this), new ParentChildRoot(clses));
        _tree.setCellRenderer(FrameRenderer.createInstance());
        int rows = _tree.getRowCount();
        int diff = rows - clses.size();
        for (int i = rows - 1; i > diff; --i) {
            _tree.expandRow(i);
        }
        _tree.setSelectionRow(0);
        setLayout(new BorderLayout());
        add(new JScrollPane(_tree), BorderLayout.CENTER);
        add(new ClsTreeFinder(kb, _tree), BorderLayout.SOUTH);
        setPreferredSize(new Dimension(300, 300));
    }

    public Collection getSelection() {
        return ComponentUtilities.getSelection(_tree);
    }

    public boolean validateContents() {
        boolean isValid = _allowsMultiple || getSelection().size() <= 1;
        if (!isValid) {
            ModalDialog.showMessageDialog(this, "Only 1 class can be selected", ModalDialog.MODE_CLOSE);
        }
        return isValid;
    }

    public void saveContents() {
        // do nothing
    }
}
