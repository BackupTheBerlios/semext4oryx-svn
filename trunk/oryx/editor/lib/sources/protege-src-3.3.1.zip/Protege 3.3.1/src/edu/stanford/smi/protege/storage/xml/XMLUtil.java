/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.storage.xml;

/**
 * Escape special XML characters.  
 * 
 * This code was inspired by that from the Apache Xerces project
 */
public class XMLUtil {

    private static final int FIRST_PRINTABLE = ' ';
    private static final int LAST_PRINTABLE = 0x7E;

    /**
     * Encode special XML characters into the equivalent character references.
     */
    private static String getEntityRef(char ch) {
        String ref;
        switch (ch) {
            case '<':
                ref = "&lt;";
                break;
            case '>':
                ref = "&gt;";
                break;
            case '"':
                ref = "&quot;";
                break;
            case '\'':
                ref = "&apos;";
                break;
            case '&':
                ref = "&amp;";
                break;
            default:
                ref = null;
                break;
        }
        return ref;
    }

    /**
     * If there is a suitable entity reference for this
     * character, return it. The list of available entity
     * references is almost but not identical between
     * XML and HTML.
     */
    public static String escape(char ch) {
        String charRef = getEntityRef(ch);
        if (charRef == null) {
            if (isPrintable(ch)) {
                charRef = "" + ch;
            } else {
                charRef = "&#" + Integer.toString(ch) + ";";
            }
        }
        return charRef;
    }

    private static boolean isPrintable(char ch) {
        return (FIRST_PRINTABLE <= ch && ch <= LAST_PRINTABLE && ch != 0xF7) || ch == '\n' || ch == '\r' || ch == '\t';
    }

    /**
     * Escapes a string so it may be returned as text content or attribute
     * value. Non printable characters are escaped using character references.
     * Where the format specifies a deault entity reference, that reference
     * is used (e.g. <tt>&amp;lt;</tt>).
     *
     * @param   source   the string to escape.
     */
    public static String escape(String source) {
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < source.length(); ++i) {
            buffer.append(escape(source.charAt(i)));
        }
        return buffer.toString();
    }

}
