/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.model;

import java.util.*;

public class FrameCountsImpl implements FrameCounts {
    private static class CountRecord {
        //ESCA-JAVA0098 
        int clsCount;
        int slotCount;
        int facetCount;
        int simpleInstanceCount;
    }

    private KnowledgeBase _kb;
    private CountRecord _systemCountRecord = new CountRecord();
    private CountRecord _includedCountRecord = new CountRecord();

    public void updateSystemFrameCounts(KnowledgeBase kb) {
        Iterator i = kb.getFrames().iterator();
        while (i.hasNext()) {
            Frame frame = (Frame) i.next();
            if (frame.isSystem()) {
                updateRecord(_systemCountRecord, frame);
            }
        }
    }

    private static void updateRecord(CountRecord record, Frame frame) {
        if (frame instanceof Cls) {
            ++record.clsCount;
        } else if (frame instanceof Slot) {
            ++record.slotCount;
        } else if (frame instanceof Facet) {
            ++record.facetCount;
        } else {
            ++record.simpleInstanceCount;
        }
    }

    public void updateIncludedFrameCounts(KnowledgeBase kb) {
        Iterator i = kb.getFrames().iterator();
        while (i.hasNext()) {
            Frame frame = (Frame) i.next();
            if (frame.isIncluded() && !frame.isSystem()) {
                updateRecord(_includedCountRecord, frame);
            }
        }
    }

    public void updateDirectFrameCounts(KnowledgeBase kb) {
        _kb = kb;
    }

    public int getSystemClsCount() {
        return _systemCountRecord.clsCount;
    }

    public int getSystemSlotCount() {
        return _systemCountRecord.slotCount;
    }

    public int getSystemFacetCount() {
        return _systemCountRecord.facetCount;
    }

    public int getSystemSimpleInstanceCount() {
        return _systemCountRecord.simpleInstanceCount;
    }

    public int getSystemFrameCount() {
        return getSystemClsCount() + getSystemSlotCount() + getSystemFacetCount() + getSystemSimpleInstanceCount();
    }

    public int getIncludedClsCount() {
        return _includedCountRecord.clsCount;
    }

    public int getIncludedSlotCount() {
        return _includedCountRecord.slotCount;
    }

    public int getIncludedFacetCount() {
        return _includedCountRecord.facetCount;
    }

    public int getIncludedSimpleInstanceCount() {
        return _includedCountRecord.simpleInstanceCount;
    }

    public int getIncludedFrameCount() {
        return getIncludedClsCount() + getIncludedSlotCount() + getIncludedFacetCount()
                + getIncludedSimpleInstanceCount();
    }

    public int getDirectClsCount() {
        return _kb.getClsCount() - (getSystemClsCount() + getIncludedClsCount());
    }

    public int getDirectSlotCount() {
        return _kb.getSlotCount() - (getSystemSlotCount() + getIncludedSlotCount());
    }

    public int getDirectFacetCount() {
        return _kb.getFacetCount() - (getSystemFacetCount() + getIncludedFacetCount());
    }

    public int getDirectSimpleInstanceCount() {
        return _kb.getSimpleInstanceCount() - (getSystemSimpleInstanceCount() + getIncludedSimpleInstanceCount());
    }

    public int getDirectFrameCount() {
        return _kb.getFrameCount() - (getSystemFrameCount() + getIncludedFrameCount());
    }

    public int getTotalClsCount() {
        return getSystemClsCount() + getIncludedClsCount() + getDirectClsCount();
    }

    public int getTotalSlotCount() {
        return getSystemSlotCount() + getIncludedSlotCount() + getDirectSlotCount();
    }

    public int getTotalFacetCount() {
        return getSystemFacetCount() + getIncludedFacetCount() + getDirectFacetCount();
    }

    public int getTotalSimpleInstanceCount() {
        return getSystemSimpleInstanceCount() + getIncludedSimpleInstanceCount() + getDirectSimpleInstanceCount();
    }

    public int getTotalFrameCount() {
        return getSystemFrameCount() + getIncludedFrameCount() + getDirectFrameCount();
    }
}