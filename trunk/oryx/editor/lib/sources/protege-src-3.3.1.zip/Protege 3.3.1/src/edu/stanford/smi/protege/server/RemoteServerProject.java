/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.server;

import java.net.URI;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Collection;

import edu.stanford.smi.protege.server.framestore.RemoteServerFrameStore;
import edu.stanford.smi.protege.server.narrowframestore.RemoteServerNarrowFrameStore;

public interface RemoteServerProject extends Remote {
    URI getURI(RemoteSession session) throws RemoteException;

    RemoteServerFrameStore getDomainKbFrameStore(RemoteSession session) throws RemoteException;
    
    String getDomainKbFactoryClassName() throws RemoteException;

    RemoteServerFrameStore getProjectKbFrameStore(RemoteSession session) throws RemoteException;
    
    String getProjectKbFactoryClassName() throws RemoteException;
    
    RemoteServerNarrowFrameStore getDomainKbNarrowFrameStore() throws RemoteException;
    
    RemoteServerNarrowFrameStore getSystemNarrowFrameStore() throws  RemoteException;

    Collection getCurrentSessions(RemoteSession session) throws RemoteException;

    void close(RemoteSession session) throws RemoteException;
    
    void register(RemoteSession session) throws RemoteException;
}