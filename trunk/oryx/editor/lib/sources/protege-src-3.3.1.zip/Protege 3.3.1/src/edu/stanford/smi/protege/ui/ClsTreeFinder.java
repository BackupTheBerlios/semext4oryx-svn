/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.ui;

import java.util.*;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.resource.*;

/**
 * Implementation of the Finder interface to locate and highlight classes whose names match a given string.  
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class ClsTreeFinder extends FrameTreeFinder {

    public ClsTreeFinder(KnowledgeBase kb, JTree tree) {
        this(kb, tree, ResourceKey.CLASS_SEARCH_FOR);
    }

    public ClsTreeFinder(KnowledgeBase kb, JTree tree, ResourceKey key) {
        super(kb, tree, key);
    }

    public ClsTreeFinder(KnowledgeBase kb, JTree tree, String description) {
        this(kb, tree, description, Icons.getFindClsIcon());
    }

    public ClsTreeFinder(KnowledgeBase kb, JTree tree, String description, Icon icon) {
        super(kb, tree, description, icon);
    }

    protected Collection getParents(Frame frame) {
        return ((Cls) frame).getDirectSuperclasses();
    }

    protected Collection getAncestors(Frame frame) {
        return ((Cls) frame).getSuperclasses();
    }

    protected boolean isCorrectType(Frame frame) {
        return frame instanceof Cls;
    }

    protected Slot getBrowserSlot(KnowledgeBase kb) {
        Slot slot;
        Cls cls = kb.getDefaultClsMetaCls();
        if (cls == null) {
            slot = kb.getNameSlot();
        } else {
            slot = cls.getBrowserSlotPattern().getFirstSlot();
        }
        return slot;
    }

    protected Set getMatchingFrames(String text, int maxMatches) {
        if (!text.endsWith("*")) {
            text += '*';
        }
        return new HashSet(getKnowledgeBase().getClsesWithMatchingBrowserText(text, Collections.EMPTY_LIST, maxMatches));
    }

}
