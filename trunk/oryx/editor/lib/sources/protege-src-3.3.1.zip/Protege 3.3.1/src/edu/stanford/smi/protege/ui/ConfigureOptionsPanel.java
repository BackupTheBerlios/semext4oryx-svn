/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.ui;

import java.awt.*;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;

/**
 * A panel to display the global options for the application and allow the user to set them.
 *
 * @author Ray Fergerson
 * @author Jennifer Vendetti
 */
class ConfigureOptionsPanel extends AbstractValidatableComponent {

    private Project _project;
    private JCheckBox _hiddenFramesComponent;
    private JCheckBox _confirmOnRemoveComponent;
    private JCheckBox _isEditableComponent;
    private JCheckBox _updateModificationSlotsComponent;

    private JCheckBox _journalingEnabledCheckBox;
    private JCheckBox _prettyPrintSlotWidgetLabelsCheckBox;
    private JCheckBox _tabbedInstanceFormCheckBox;
    private JCheckBox _enableUndoCheckBox;
    private JCheckBox _addNameOnInstanceFormCheckBox;
    private JCheckBox _trackChangesActiveComponent;
    
    ConfigureOptionsPanel(Project project) {
        _project = project;
        setLayout(new BorderLayout());
        JComponent c = new Box(BoxLayout.Y_AXIS);
        c.add(createHiddenClassesComponent());
        c.add(createConfirmOnRemoveComponent());
        c.add(createIsEditableComponent());
        c.add(createUpdateModificationSlotsComponent());
        c.add(createChangeTrackingActiveComponent());
        c.add(createJournalingEnabledCheckBox());
        c.add(createPrettyPrintSlotWidgetLabelsCheckBox());
        c.add(createTabbedInstanceFormComponent());
        c.add(createEnableUndoCheckBox());
        c.add(createNameOnInstanceFormComponent());
        add(c);

    }

    private JComponent createEnableUndoCheckBox() {
    	_enableUndoCheckBox = ComponentFactory.createCheckBox();
    	_enableUndoCheckBox.setText("Enable Undo/Redo of operations");
    	_enableUndoCheckBox.setSelected(_project.isUndoOptionEnabled());
        return _enableUndoCheckBox;
	}

	private JComponent createJournalingEnabledCheckBox() {
        _journalingEnabledCheckBox = ComponentFactory.createCheckBox();
        _journalingEnabledCheckBox.setText("Enable Journaling");
        _journalingEnabledCheckBox.setSelected(_project.isJournalingEnabled());
        return _journalingEnabledCheckBox;
    }

    private JComponent createPrettyPrintSlotWidgetLabelsCheckBox() {
        _prettyPrintSlotWidgetLabelsCheckBox = ComponentFactory.createCheckBox();
        _prettyPrintSlotWidgetLabelsCheckBox.setText("Capitalize Slot Widget Labels");
        _prettyPrintSlotWidgetLabelsCheckBox.setSelected(_project.getPrettyPrintSlotWidgetLabels());
        return _prettyPrintSlotWidgetLabelsCheckBox;
    }

    private JComponent createConfirmOnRemoveComponent() {
        _confirmOnRemoveComponent = ComponentFactory
                .createCheckBox("Display Confirmation Dialog on 'Remove' Operations");
        setValue(_confirmOnRemoveComponent, _project.getDisplayConfirmationOnRemove());
        return _confirmOnRemoveComponent;
    }

    private JComponent createHiddenClassesComponent() {
        _hiddenFramesComponent = ComponentFactory.createCheckBox("Display Hidden Frames");
        setValue(_hiddenFramesComponent, _project.getDisplayHiddenClasses());
        return _hiddenFramesComponent;
    }

    private JComponent createIsEditableComponent() {
        _isEditableComponent = ComponentFactory.createCheckBox("Allow Knowledge-Base Changes");
        setValue(_isEditableComponent, !_project.isReadonly());
        return _isEditableComponent;
    }

    private JComponent createUpdateModificationSlotsComponent() {    	
        _updateModificationSlotsComponent = ComponentFactory.createCheckBox("Update modification slots");
        setValue(_updateModificationSlotsComponent, _project.getUpdateModificationSlots());
        return _updateModificationSlotsComponent;
    }

    private JComponent createChangeTrackingActiveComponent() {    	
        _trackChangesActiveComponent = ComponentFactory.createCheckBox("Track changes");
        setValue(_trackChangesActiveComponent, _project.getChangeTrackingActive());
        return _trackChangesActiveComponent;
    }

    
    private JComponent createTabbedInstanceFormComponent() {
        _tabbedInstanceFormCheckBox = ComponentFactory.createCheckBox("Used Tabbed Forms for Multi-Type Instances");
        setValue(_tabbedInstanceFormCheckBox, _project.getTabbedInstanceFormLayout());
        return _tabbedInstanceFormCheckBox;
    }

    private JComponent createNameOnInstanceFormComponent() {
        _addNameOnInstanceFormCheckBox = ComponentFactory.createCheckBox("Add :NAME Slot on Instance Forms");
        setValue(_addNameOnInstanceFormCheckBox, _project.getAddNameOnInstanceForm());
        return _addNameOnInstanceFormCheckBox;
    }
    
    private static boolean getValue(JCheckBox box) {
        return box.isSelected();
    }

    public void saveContents() {
        _project.setDisplayHiddenClasses(getValue(_hiddenFramesComponent));
        // _project.setDisplayMultiParentClassIcon(getValue(_multiParentClassIconComponent));
        _project.setDisplayConfirmationOnRemove(getValue(_confirmOnRemoveComponent));
        _project.setIsReadonly(!getValue(_isEditableComponent));
        _project.setUpdateModificationSlots(getValue(_updateModificationSlotsComponent));
        _project.setChangeTrackingActive(getValue(_trackChangesActiveComponent));
        _project.setJournalingEnabled(getValue(_journalingEnabledCheckBox));
        _project.setPrettyPrintSlotWidgetLabels(getValue(_prettyPrintSlotWidgetLabelsCheckBox));
        _project.setTabbedInstanceFormLayout(getValue(_tabbedInstanceFormCheckBox));
        _project.setAddNameOnInstanceForm(getValue(_addNameOnInstanceFormCheckBox));
        _project.setUndoOption(getValue(_enableUndoCheckBox));
    }

    private static void setValue(JCheckBox box, boolean value) {
        box.setSelected(value);
    }

    public boolean validateContents() {
        return true;
    }
}