/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.server;

import java.awt.*;
import java.rmi.*;
import java.util.*;

import javax.swing.*;
import javax.swing.table.*;

import edu.stanford.smi.protege.util.*;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class ServerProjectPanel extends JPanel {
    private RemoteServer _server;
    private RemoteSession _session;
    private JTable _projectTable;

    public ServerProjectPanel(RemoteServer server, RemoteSession session) {
        _server = server;
        _session = session;
        _projectTable = ComponentFactory.createTable(null);
        setLayout(new BorderLayout());
        add(ComponentFactory.createScrollPane(_projectTable));
        loadTable();
        setMinimumSize(new Dimension(400, 300));
    }

    private void loadTable() {
        try {
            Collection names = _server.getAvailableProjectNames(_session);
            Iterator iterator = names.iterator();
            Object[][] data = new Object[names.size()][2];
            for (int i = 0; i < names.size(); ++i) {
                //ESCA-JAVA0282 
                String name = (String) iterator.next();
                data[i][0] = name;
                data[i][1] = sessionsToString(_server.getCurrentSessions(name, _session));
            }
            Object[] columns = new Object[] { "Project", "Current Users" };
            _projectTable.setModel(new DefaultTableModel(data, columns));
            _projectTable.createDefaultColumnsFromModel();
            if (names.size() > 0) {
            	_projectTable.setRowSelectionInterval(0, 0);
            }
        } catch (RemoteException e) {
            Log.getLogger().severe(Log.toString(e));
        }
    }

    private static String sessionsToString(Collection userNames) {
        StringBuffer s = new StringBuffer();
        Iterator i = userNames.iterator();
        while (i.hasNext()) {
            Session session = (Session) i.next();
            if (s.length() > 0) {
                s.append(", ");
            }
            s.append(session.getUserName() + " (" + session.getUserIpAddress() + ")");
        }
        return s.toString();
    }

    public String getProjectName() {
        String name;
        int row = _projectTable.getSelectedRow();
        if (row < 0) {
            name = null;
        } else {
            name = (String) _projectTable.getValueAt(row, 0);
        }
        return name;
    }
}