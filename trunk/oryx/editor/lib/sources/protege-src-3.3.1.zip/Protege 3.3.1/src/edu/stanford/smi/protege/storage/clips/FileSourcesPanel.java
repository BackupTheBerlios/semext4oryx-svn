/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.storage.clips;

import java.awt.*;
import java.net.*;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;

/**
 * Panel which contains the fields needed for the Clips backend.  This is just the .pont (classes) 
 * and .pins (instances) file names.
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class FileSourcesPanel extends KnowledgeBaseSourcesEditor {
    private FileField _clsesField;
    private FileField _instancesField;

    public FileSourcesPanel(String projectURIString, PropertyList sources) {
        super(projectURIString, sources);
        Box box = Box.createVerticalBox();
        box.add(createClsesField());
        box.add(createInstancesField());
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(box, BorderLayout.NORTH);
        add(panel);
    }

    //ESCA-JAVA0130 
    public URI getProjectURI() {
        return null;
        // return getProjectURI(_clsesField);
    }

    public void saveContents() {
        String clsesFileName = getBaseFile(_clsesField);
        String instancesFileName = getBaseFile(_instancesField);
        ClipsKnowledgeBaseFactory.setSourceFiles(getSources(), clsesFileName, instancesFileName);
    }

    public boolean validateContents() {
        return true;
    }
    protected JComponent createClsesField() {
        String file = ClipsKnowledgeBaseFactory.getClsesSourceFile(getSources());
        _clsesField = new FileField("Classes file name", file, ".pont", "Ontology");
        return _clsesField;
    }

    protected JComponent createInstancesField() {
        String file = ClipsKnowledgeBaseFactory.getInstancesSourceFile(getSources());
        _instancesField = new FileField("Instances file name", file, ".pins", "Instances");
        return _instancesField;
    }

    public void onProjectPathChange(String oldPath, String newPath) {
        super.onProjectPathChange(oldPath, newPath);
        if (newPath != null) {
            updatePath(_clsesField, newPath, ".pont");
            updatePath(_instancesField, newPath, ".pins");
        }
    }

}
