/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.rmi.server.RMISocketFactory;

import edu.stanford.smi.protege.util.Log;
import edu.stanford.smi.protege.util.StringUtilities;

/* This code is based on an idea from here:
 * http://www.javacoding.net/articles/technical/rmi-firewall.html
 *
 * Author: Tim Goffings 
 * Date: Oct 3, 2002 - 3:51:34 PM 
 */

public class ServerRmiSocketFactory extends RMISocketFactory {
    private int fixedPort;

    public ServerRmiSocketFactory() {
        fixedPort = Integer.getInteger(ServerProperties.SERVER_PORT, 0).intValue();
        if (fixedPort != 0) {
            Log.getLogger().config("fixed port=" + fixedPort);
        }
    }
    
    public Socket createSocket(String host, int port) throws IOException {
        Socket socket = new Socket(host, port);
        if (fixedPort != 0) {
            Log.getLogger().config("local port: " + socket.getLocalPort());
        }
        return socket;
    }

    /*
     * This method gets passed a 0 to indicate "allocate any port".  If the user has specfied a
     * port then we use it.
     */
    public ServerSocket createServerSocket(int requestedPort) throws IOException {
        int port = requestedPort == 0 ? fixedPort : requestedPort;
        ServerSocket socket = new ServerSocket(port);
        if (fixedPort != 0) {
            Log.getLogger().config("local port: " + socket.getLocalPort());
        }
        return socket;
    }
    
    public String toString() {
        return StringUtilities.getClassName(this);
    }
}
