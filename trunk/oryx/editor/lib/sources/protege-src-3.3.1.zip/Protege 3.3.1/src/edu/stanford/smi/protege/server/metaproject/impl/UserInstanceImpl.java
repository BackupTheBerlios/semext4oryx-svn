/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.server.metaproject.impl;

import java.io.Serializable;
import java.util.Set;

import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.server.metaproject.GroupInstance;
import edu.stanford.smi.protege.server.metaproject.UserInstance;
import edu.stanford.smi.protege.server.metaproject.MetaProject.ClsEnum;
import edu.stanford.smi.protege.server.metaproject.MetaProject.SlotEnum;

public class UserInstanceImpl extends WrappedProtegeInstanceImpl implements UserInstance, Serializable {
  private static final long serialVersionUID = -4416984896523630762L;
  
  private String name;
  private String password;
  private Set<GroupInstance> groups;

  
  @SuppressWarnings("unchecked")
  protected UserInstanceImpl(MetaProjectImpl mp, Instance ui) {
    super(mp, ui, ClsEnum.User);
    name = (String) ui.getOwnSlotValue(mp.getSlot(SlotEnum.name));
    password = (String) ui.getOwnSlotValue(mp.getSlot(SlotEnum.password));
    groups = (Set<GroupInstance>) getSlotValues(SlotEnum.group, ClsEnum.Group);
  }
  
  public UserInstanceImpl(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public String getPassword() {
    return password;
  }
  
  public Set<GroupInstance> getGroups() {
    return groups;
  }
  
  public boolean equals(Object o) { 
    if (!(o instanceof UserInstance)) {
      return false;
    }
    UserInstance other = (UserInstance) o;
    return name.equals(other.getName());
  }
  
  public int hashCode() {
    return name.hashCode();
  }
  
  public String toString() {
    return name;
  }
  
  public void setName(String name) {
	  setSlotValue(SlotEnum.name, name);
  }
  
  public void setPassword(String password) {
	  setSlotValue(SlotEnum.password, password);
  }
  
}
