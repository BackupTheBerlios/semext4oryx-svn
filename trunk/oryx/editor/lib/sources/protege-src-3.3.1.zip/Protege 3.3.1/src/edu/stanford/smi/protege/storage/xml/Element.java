/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.storage.xml;

import java.util.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

import edu.stanford.smi.protege.util.*;

class Element {
    private String name;
    private Attributes attributes;
    private String value;
    private List subelements;

    Element(String name, Attributes attributes) {
        this.name = name;
        this.attributes = new AttributesImpl(attributes);
    }

    public void addCharacters(String s) {
        if (value == null) {
            value = s;
        } else {
            value += s;
        }
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

    public void addElement(Element element) {
        if (subelements == null) {
            subelements = new ArrayList();
        }
        subelements.add(element);
    }

    public String getAttributeValue(String type) {
        return attributes.getValue(type);
    }

    public Element getSubelement(int index) {
        return (Element) subelements.get(index);
    }

    public Collection getSubelements() {
        //ESCA-JAVA0259 
        return subelements;
    }

    public String getSubelementValue(String tag) {
        return (String) CollectionUtilities.getFirstItem(getSubelementValues(tag));
    }

    public Collection getSubelementValues(String tag) {
        Collection values = new ArrayList();
        Iterator i = subelements.iterator();
        while (i.hasNext()) {
            Element element = (Element) i.next();
            if (element.getName().equals(tag)) {
                values.add(element.getValue());
            }
        }
        return values;
    }

    public Collection getSubelements(String tag) {
        Collection elements = new ArrayList();
        Iterator i = subelements.iterator();
        while (i.hasNext()) {
            Element element = (Element) i.next();
            if (element.getName().equals(tag)) {
                elements.add(element);
            }
        }
        return elements;

    }

}
