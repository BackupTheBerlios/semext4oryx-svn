/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.model.framestore;

import java.lang.reflect.*;
import java.util.logging.*;

import edu.stanford.smi.protege.server.*;
import edu.stanford.smi.protege.server.framestore.ServerFrameStore;
import edu.stanford.smi.protege.util.*;

/**
 * TODO Class Comment
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class JournalFormater extends AbstractFormatter {
    private final String appUsername;

    public JournalFormater() {
        this.appUsername = ApplicationProperties.getUserName();
    }

    private String getUsername() {
        RemoteSession session = ServerFrameStore.getCurrentSession();
        return session == null ? appUsername : session.getUserName();
    }

    public String format(LogRecord record) {
        StringBuffer buffer = new StringBuffer();
        buffer.append(getDateString());
        buffer.append(" ");
        buffer.append(getUsername());
        buffer.append(" - ");
        Object[] params = record.getParameters();
        Method method = (Method) params[0];
        buffer.append(method.getName());
        buffer.append("(");
        for (int i = 1; i < params.length - 1; ++i) {
            Object param = params[i];
            if (i != 1) {
                buffer.append(", ");
            }
            buffer.append(toString(param));
        }
        buffer.append(") returns ");
        Object result = params[params.length - 1];
        buffer.append(toString(result));
        buffer.append(getLineSeparator());
        return buffer.toString();
    }

}