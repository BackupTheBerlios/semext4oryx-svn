/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.model.framestore;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import edu.stanford.smi.protege.exception.ProtegeError;
import edu.stanford.smi.protege.model.Facet;
import edu.stanford.smi.protege.model.Frame;
import edu.stanford.smi.protege.model.FrameID;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protege.model.query.Query;
import edu.stanford.smi.protege.model.query.QueryCallback;
import edu.stanford.smi.protege.util.transaction.TransactionMonitor;

/**
 * This is a placeholder with no functionality.  It is used as the root of a tree of 
 * NarrowFrameStore objects.
 * @author tredmond
 *
 */
public class PlaceHolderNarrowFrameStore implements NarrowFrameStore {

	public String getName() {
		throw new UnsupportedOperationException("Not implemented yet");
	}

	public void setName(String name) {
		throw new UnsupportedOperationException("Not implemented yet");
	}

	public NarrowFrameStore getDelegate() {
		throw new UnsupportedOperationException("Not implemented yet");
	}

	public FrameID generateFrameID() {
		throw new UnsupportedOperationException("Not implemented yet");
	}

	public int getFrameCount() {
		throw new UnsupportedOperationException("Not implemented yet");
	}

	public int getClsCount() {
		throw new UnsupportedOperationException("Not implemented yet");
	}

	public int getSlotCount() {
		throw new UnsupportedOperationException("Not implemented yet");
	}

	public int getFacetCount() {
		throw new UnsupportedOperationException("Not implemented yet");
	}

	public int getSimpleInstanceCount() {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public Set getFrames() {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public Frame getFrame(FrameID id) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public List getValues(Frame frame, Slot slot, Facet facet,
			boolean isTemplate) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public int getValuesCount(Frame frame, Slot slot, Facet facet,
			boolean isTemplate) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public void addValues(Frame frame, Slot slot, Facet facet,
			boolean isTemplate, Collection values) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public void moveValue(Frame frame, Slot slot, Facet facet,
			boolean isTemplate, int from, int to) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public void removeValue(Frame frame, Slot slot, Facet facet,
			boolean isTemplate, Object value) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public void setValues(Frame frame, Slot slot, Facet facet,
			boolean isTemplate, Collection values) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public Set getFrames(Slot slot, Facet facet, boolean isTemplate,
			Object value) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public Set getFramesWithAnyValue(Slot slot, Facet facet, boolean isTemplate) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public Set getMatchingFrames(Slot slot, Facet facet, boolean isTemplate,
			String value, int maxMatches) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public Set getReferences(Object value) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public Set getMatchingReferences(String value, int maxMatches) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public void  executeQuery(Query query, final QueryCallback callback) {
          new Thread() {
            public void run() {
              callback.handleError(new ProtegeError("Not implemented yet"));
            }
          };
	}

	public void deleteFrame(Frame frame) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public void close() {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public Set getClosure(Frame frame, Slot slot, Facet facet,
			boolean isTemplate) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public void replaceFrame(Frame frame) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public boolean beginTransaction(String name) {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public boolean commitTransaction() {

		throw new UnsupportedOperationException("Not implemented yet");
	}

	public boolean rollbackTransaction() {

		throw new UnsupportedOperationException("Not implemented yet");
	}

        public TransactionMonitor getTransactionStatusMonitor() {
          throw new UnsupportedOperationException();
        }
}
