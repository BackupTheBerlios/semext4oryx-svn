/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.server;

import java.io.Serializable;


public class Session implements RemoteSession, Serializable {
    private static int nextId = 100;
    private int id;
    private String userName;
    private String userIpAddress;
    private long startTime;
    private long lastAccessTime;

    public Session(String userName, String userIpAddress) {
        this.id = nextId++;
        this.userName = userName;
        this.userIpAddress = userIpAddress;
        this.startTime = currentTime();
        this.lastAccessTime = startTime;
    }

    public Session() {

    }
    
    /* from Externalizable interface
    public void writeExternal(ObjectOutput output) throws IOException {
        output.writeInt(id);
        output.writeUTF(userName);
        output.writeUTF(userIpAddress);
        output.writeLong(startTime);
        output.writeLong(lastAccessTime);
    }

    public void readExternal(ObjectInput input) throws IOException {
        id = input.readInt();
        userName = input.readUTF();
        userIpAddress = input.readUTF();
        startTime = input.readLong();
        lastAccessTime = input.readLong();

    }
    */

    public String getUserName() {
        return userName;
    }

    public String getUserIpAddress() {
        return userIpAddress;
    }

    public long getLastAccessTime() {
        return lastAccessTime;
    }

    public void updateAccessTime() {
        lastAccessTime = currentTime();
    }

    private static long currentTime() {
        return System.currentTimeMillis();
    }

    public boolean equals(Object o) {
        return id == ((Session) o).id;
    }

    public int hashCode() {
        return id;
    }

    public String toString() {
        return "Session(id=" + id + ", user=" + userName + ")";
    }
}