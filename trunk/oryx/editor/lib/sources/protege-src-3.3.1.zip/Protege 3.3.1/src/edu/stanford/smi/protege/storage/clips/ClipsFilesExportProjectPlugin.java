/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.storage.clips;

import java.io.*;
import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.plugin.*;
import edu.stanford.smi.protege.util.*;

/**
 * Export plugins for the CLIPS file format.
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class ClipsFilesExportProjectPlugin extends AbstractBackendExportPlugin implements ClipsFilesPlugin {
    private String clsesFileName;
    private String instancesFileName;

    public ClipsFilesExportProjectPlugin() {
        super(ClipsKnowledgeBaseFactory.DESCRIPTION);
    }

    public boolean canExport(Project project) {
        return true;
    }

    public boolean canExportToNewFormat(Project project) {
        return canExport(project);
    }
    
    public WizardPage createExportWizardPage(ExportWizard wizard, Project project) {
        return new ClipsFilesWizardPage(wizard, this);
    }

    public WizardPage createExportToNewFormatWizardPage(ExportWizard wizard, Project project) {
        return new ClipsExportToNewFormatWizardPage(wizard, project, this);
    }

    protected void overwriteDomainInformation(Project project, Collection errors) {
        KnowledgeBase kb = project.getKnowledgeBase();
        new ClipsKnowledgeBaseFactory().saveKnowledgeBase(kb, clsesFileName, instancesFileName, errors);
    }

    protected void initializeSources(Project project, Collection errors) {
        PropertyList sources = project.getSources();
        project.setKnowledgeBaseFactory(new ClipsKnowledgeBaseFactory());
        ClipsKnowledgeBaseFactory.setSourceFiles(sources, clsesFileName, instancesFileName);
    }

    public void setFiles(String clsesFileName, String instancesFileName) {
        this.clsesFileName = clsesFileName;
        this.instancesFileName = instancesFileName;
    }
    
    public void exportProject(Project project) {
        Writer clsesWriter = null;
        Writer instancesWriter = null;
        try {
            Collection errors = new ArrayList();
            KnowledgeBase kb = project.getKnowledgeBase();
            ClipsKnowledgeBaseFactory factory = new ClipsKnowledgeBaseFactory();
            clsesWriter = FileUtilities.getWriter(clsesFileName);
            instancesWriter = FileUtilities.getWriter(instancesFileName);
            factory.saveKnowledgeBase(kb, clsesWriter, instancesWriter, errors);
            handleErrors(errors);
        } finally {
            FileUtilities.close(clsesWriter);
            FileUtilities.close(instancesWriter);
        }
    }
}