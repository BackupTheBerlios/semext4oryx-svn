/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.ui;

import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.List;

import javax.swing.*;

import edu.stanford.smi.protege.plugin.*;
import edu.stanford.smi.protege.util.*;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class AboutPluginsBox extends JPanel {
    private JList pluginsList;
    private JEditorPane aboutViewer;

    public AboutPluginsBox() {
        pluginsList = createPluginsList();
        aboutViewer = createAboutViewer();
        layoutComponents();
    }

    private JList createPluginsList() {
        SelectableList list = ComponentFactory.createSelectableList(null);
        ListModel model = createPluginsModel();
        list.setModel(model);
        list.addSelectionListener(new SelectionListener() {
            public void selectionChanged(SelectionEvent event) {
                String componentName = (String) pluginsList.getSelectedValue();
                if (componentName != null) {
                    URL url = PluginUtilities.getPluginComponentAboutURL(componentName);
                    try {
                        aboutViewer.setPage(url);
                    } catch (IOException e) {
                        Log.getLogger().warning(e.toString());
                    }
                }
            }
        });
        list.setPreferredSize(new Dimension(150, 150));
        return list;
    }

    private static ListModel createPluginsModel() {
        List names = new ArrayList(PluginUtilities.getPluginComponentNames());
        Iterator i = names.iterator();
        while (i.hasNext()) {
            String name = (String) i.next();
            URL url = PluginUtilities.getPluginComponentAboutURL(name);
            if (url == null) {
                i.remove();
            }
        }
        Collections.sort(names);
        return new SimpleListModel(names);
    }

    private static JEditorPane createAboutViewer() {
        JEditorPane pane = ComponentFactory.createHTMLBrowser(null);
        pane.setPreferredSize(new Dimension(600, 600));
        return pane;
    }

    private void layoutComponents() {
        setLayout(new BorderLayout());
        JComponent left = new LabeledComponent("Installed Plugins", new JScrollPane(pluginsList));
        JComponent right = new LabeledComponent("About Selected Plugin", new JScrollPane(aboutViewer));
        JSplitPane pane = ComponentFactory.createLeftRightSplitPane(left, right);
        add(pane);
    }
}
