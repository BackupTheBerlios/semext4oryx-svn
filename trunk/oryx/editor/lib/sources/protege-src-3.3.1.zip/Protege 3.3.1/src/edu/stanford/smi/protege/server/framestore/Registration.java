/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.server.framestore;


import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import edu.stanford.smi.protege.server.update.ValueUpdate;
import edu.stanford.smi.protege.server.util.FifoReader;
import edu.stanford.smi.protege.server.util.FifoWriter;
import edu.stanford.smi.protege.util.AbstractEvent;

/**
 * @author Ray Fergerson
 *
 * Description of this class
 */
public class Registration {
    private static final transient Logger cacheLog = ServerFrameStore.cacheLog;
  
    private FifoReader<AbstractEvent> events;
    private FifoReader<ValueUpdate> updates;
    private List<AbstractEvent> transactionEvents = new ArrayList<AbstractEvent>();
    private List<ValueUpdate> commits = new ArrayList<ValueUpdate>();
    private long lastHeartbeat = 0;


    public Registration(FifoWriter<AbstractEvent> events,
                        FifoWriter<ValueUpdate> updates) {
        this.events = new FifoReader<AbstractEvent>(events);
        this.updates = new FifoReader<ValueUpdate>(updates);
    }
 
    public FifoReader<AbstractEvent> getEvents() {
        return events;
    }

    public FifoReader<ValueUpdate> getUpdates() {
      return updates;
    }
    
    public void addCommittableUpdate(ValueUpdate vu) {
      if (cacheLog.isLoggable(Level.FINE)) {
        cacheLog.fine("Saving an update for commit/rollback " + vu);
      }
      commits.add(vu);
    }
    
    public List<ValueUpdate>  getCommits() {
      return commits;
    }

    public void clearCommits() {
      getCommits();
    }

    public void addTransactionEvent(AbstractEvent event) {
      if (cacheLog.isLoggable(Level.FINE)) {
        cacheLog.fine("Saving event " + event + " for commit/rollback");
      }
      transactionEvents.add(event);
    }

    public List<AbstractEvent> getTransactionEvents() {
      return transactionEvents;
    }

    public void endTransaction() {
      if (cacheLog.isLoggable(Level.FINE)) {
        cacheLog.fine("Ending transaction: clearing transaction local events and updates");
      }
      commits = new ArrayList<ValueUpdate>();
      transactionEvents = new ArrayList<AbstractEvent>();
    }
    
    public long getLastHeartbeat() {
      return lastHeartbeat;
    }

    public void setLastHeartbeat(long lastHeartbeat) {
      this.lastHeartbeat = lastHeartbeat;
    }


}
