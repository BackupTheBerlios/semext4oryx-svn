/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in 
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2007.  All Rights Reserved.
 *
 * Protege was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu.
 *
 */

package edu.stanford.smi.protege.ui;


import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.resource.*;
import edu.stanford.smi.protege.util.*;

/**
 * Renderer for the value-type facet.
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class TypeFacetRenderer extends DefaultRenderer {
    public void load(Object o) {
        FrameSlotCombination combination = (FrameSlotCombination) o;
        Cls cls = (Cls) combination.getFrame();
        Slot slot = combination.getSlot();
        ValueType type = cls.getTemplateSlotValueType(slot);
        String text = type.toString();
        if (type == ValueType.INSTANCE) {
            Collection clses = cls.getTemplateSlotAllowedClses(slot);
            text = append(text, "of", clses);
        } else if (type == ValueType.CLS) {
            Collection clses = cls.getTemplateSlotAllowedParents(slot);
            text = append(text, "with superclass", clses);
        }
        setMainText(text);
        setGrayedText(!combination.getFrame().isEditable());
        setBackgroundSelectionColor(Colors.getSlotSelectionColor());
    }
    
    private static String append(String text, String separator, Collection clses) {
	    if (!clses.isEmpty()) {
	        text += " " + separator + " ";
	        boolean first = true;
	        Iterator i = clses.iterator();
	        while (i.hasNext()) {
	            Cls cls = (Cls) i.next();
	            if (!first) {
	                text += " or ";
	            }
	            first = false;
	            text += cls.getBrowserText();
	        }
	    }
	    return text;
    }
}
